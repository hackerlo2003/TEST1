﻿using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        string logName = "test";           // Log name -> creates test.evtx
        string sourceName = "MyAppSource";  // Event source name

        try
        {
            // Create the source if it doesn't exist (requires Administrator privileges)
            if (!EventLog.SourceExists(sourceName))
            {
                EventLog.CreateEventSource(sourceName, logName);
                Console.WriteLine($"Created event source '{sourceName}' in log '{logName}'.");
            }

            using (EventLog eventLog = new EventLog(logName))
            {
                eventLog.Source = sourceName;

                eventLog.WriteEntry(    
                    "This is a test entry written to the event log.",
                    EventLogEntryType.Information,
                    eventID: 1000
                );

                Console.WriteLine("Entry successfully written to the event log.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}