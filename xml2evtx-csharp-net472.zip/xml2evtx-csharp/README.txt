Xml2Evtx - C# .NET Framework 4.7.2 port

Build (Developer Command Prompt for VS):
  csc /target:exe /out:Xml2Evtx.exe Xml2Evtx.cs

Usage:
  Xml2Evtx.exe -x input.xml
  Xml2Evtx.exe -x input.xml -v
  Xml2Evtx.exe -t

The program intentionally mirrors the structure/encoding logic of the supplied Python xml2evtx.py and uses only .NET Framework classes.
