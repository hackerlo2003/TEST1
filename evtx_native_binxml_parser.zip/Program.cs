using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace EvtxNativeParser
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = args.Length > 0
                ? args[0]
                : @"C:\Windows\System32\winevt\Logs\Security.evtx";

            if (!File.Exists(path))
            {
                Console.WriteLine("[-] File not found: " + path);
                return;
            }

            byte[] file = File.ReadAllBytes(path);

            if (file.Length < 4096 + 65536 ||
                Encoding.ASCII.GetString(file, 0, 7) != "ElfFile")
            {
                Console.WriteLine("[-] Invalid EVTX file.");
                return;
            }

            int chunkOffset = 4096;
            int recordOffset = FindFirstRecord(file, chunkOffset, chunkOffset + 65536);

            if (recordOffset < 0)
            {
                Console.WriteLine("[-] Record not found.");
                return;
            }

            uint recordSize = ReadU32(file, recordOffset + 4);
            ulong recordId = ReadU64(file, recordOffset + 8);
            ulong timestamp = ReadU64(file, recordOffset + 16);

            int binSize = checked((int)recordSize - 28);

            if (recordSize < 28 ||
                recordOffset + recordSize > file.Length ||
                binSize <= 0)
            {
                Console.WriteLine("[-] Invalid record.");
                return;
            }

            byte[] binxml = new byte[binSize];
            Buffer.BlockCopy(file, recordOffset + 24, binxml, 0, binSize);

            Console.WriteLine("========================================");
            Console.WriteLine("RECORD");
            Console.WriteLine("========================================");
            Console.WriteLine("Record Size : " + recordSize);
            Console.WriteLine("Record ID   : " + recordId);
            Console.WriteLine("BinXML Size : " + binSize);

            try
            {
                Console.WriteLine("Time        : " +
                    DateTime.FromFileTimeUtc((long)timestamp)
                        .ToString("yyyy-MM-dd HH:mm:ss.fffffff") + " UTC");
            }
            catch
            {
                Console.WriteLine("Time        : invalid");
            }

            BinXmlParser parser =
                new BinXmlParser(file, binxml, chunkOffset);

            Console.WriteLine();
            Console.WriteLine("========================================");
            Console.WriteLine("BINXML PARSED");
            Console.WriteLine("========================================");

            try
            {
                string xml = parser.ParseDocument();
                Console.WriteLine(xml);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[-] BinXML parse error: " + ex.Message);
                Console.WriteLine();
                Console.WriteLine("[!] Raw BinXML was not modified.");
            }
        }

        static int FindFirstRecord(byte[] data, int start, int end)
        {
            for (int i = start; i + 4 <= end; i++)
            {
                if (data[i] == 0x2A &&
                    data[i + 1] == 0x2A &&
                    data[i + 2] == 0x00 &&
                    data[i + 3] == 0x00)
                    return i;
            }
            return -1;
        }

        static uint ReadU32(byte[] b, int p)
        {
            return BitConverter.ToUInt32(b, p);
        }

        static ulong ReadU64(byte[] b, int p)
        {
            return BitConverter.ToUInt64(b, p);
        }
    }

    class BinXmlParser
    {
        readonly byte[] File;
        readonly byte[] Bin;
        readonly int ChunkOffset;

        readonly Dictionary<ushort, ValueSpec> Values =
            new Dictionary<ushort, ValueSpec>();

        int TemplateDataCursor;
        int TemplateDataEnd;

        public BinXmlParser(byte[] file, byte[] bin, int chunkOffset)
        {
            File = file;
            Bin = bin;
            ChunkOffset = chunkOffset;
        }

        public string ParseDocument()
        {
            int p = 0;

            StringBuilder xml = new StringBuilder();

            while (p < Bin.Length)
            {
                byte token = Bin[p];

                if (token == 0x0F)
                {
                    p += 4;
                    continue;
                }

                if (token == 0x0C)
                {
                    p = ParseTemplateInstance(p, xml);
                    continue;
                }

                if (token == 0x00)
                    break;

                p = ParseElement(p, xml, false);

                if (p <= 0)
                    throw new InvalidDataException("Invalid BinXML token.");
            }

            return xml.ToString();
        }

        int ParseTemplateInstance(int p, StringBuilder xml)
        {
            int start = p;

            if (p + 1 + 33 > Bin.Length)
                throw new InvalidDataException("Truncated TemplateInstance.");

            p++; // 0x0c

            // Embedded template-definition header used by EVTX:
            // version/flags + template identifier + data offset +
            // next definition + GUID + definition byte length.
            byte version = Bin[p++];
            uint templateId = ReadU32(Bin, p); p += 4;
            uint templateDataOffset = ReadU32(Bin, p); p += 4;
            uint nextTemplateOffset = ReadU32(Bin, p); p += 4;
            p += 16; // GUID

            uint templateLength = ReadU32(Bin, p);
            p += 4;

            // The template definition is stored relative to the chunk.
            int templateStartAbs =
                checked(ChunkOffset + (int)templateDataOffset);

            int templateStartBin =
                templateStartAbs - (ChunkOffset + 0); // absolute file position

            // Our BinXML begins at record+24, so convert file absolute to Bin offset.
            // If the definition is before this record, it is not contained in BinXML.
            // In that case parse it directly from File[].
            string templateXml;

            if (templateStartAbs >= 0 &&
                templateStartAbs + 4 < File.Length)
            {
                templateXml = ParseTemplateDefinitionFromFile(
                    templateStartAbs,
                    (int)templateLength);
            }
            else
            {
                throw new InvalidDataException("Template definition offset is invalid.");
            }

            // Template instance data begins immediately after the template definition
            // represented in this instance. For common EVTX records the next bytes in
            // the record are the ValueSpec. Locate it by searching forward from p for
            // a plausible DWORD NumValues and descriptors, stopping at the template
            // definition EOF when possible.
            int dataStart = FindValueSpec(p);

            if (dataStart < 0)
            {
                // If the template definition is embedded immediately after the header,
                // use its end as a fallback.
                int fallback = p + (int)templateLength;
                if (fallback < Bin.Length)
                    dataStart = fallback;
            }

            if (dataStart < 0 || dataStart + 4 > Bin.Length)
                throw new InvalidDataException("Template instance ValueSpec not found.");

            ParseValueSpec(dataStart);

            // Re-render template definition with substitutions.
            // ParseTemplateDefinitionFromFile already rendered its structure,
            // but we need the actual substitution mapping. Re-run using current Values.
            templateXml = ParseTemplateDefinitionFromFile(
                templateStartAbs,
                (int)templateLength);

            xml.Append(templateXml);

            // Advance over ValueSpec + raw values.
            int total = 0;
            foreach (ValueSpec v in Values.Values)
                total += v.Size;

            TemplateDataCursor = dataStart + 4 + Values.Count * 4;
            TemplateDataEnd = TemplateDataCursor + total;

            if (TemplateDataEnd <= Bin.Length)
            {
                // consume actual values; the caller only needs the XML
                return Math.Max(TemplateDataEnd, p);
            }

            return p;
        }

        string ParseTemplateDefinitionFromFile(int absStart, int length)
        {
            int end = Math.Min(File.Length, absStart + length);
            int p = absStart;

            // Template definition header is outside the fragment data in the
            // usual embedded representation. Search for fragment header 0x0f.
            int fragment = FindByte(File, 0x0F, p, end);

            if (fragment < 0)
                return "";

            StringBuilder xml = new StringBuilder();

            try
            {
                ParseFileElement(fragment, end, xml);
            }
            catch
            {
                // Keep whatever was successfully rendered.
            }

            return xml.ToString();
        }

        int FindValueSpec(int p)
        {
            // Prefer the first plausible NumValues followed by N descriptors.
            for (int i = p; i + 8 <= Bin.Length; i++)
            {
                uint n = ReadU32(Bin, i);

                if (n == 0 || n > 512)
                    continue;

                long descriptorEnd = (long)i + 4 + (long)n * 4;

                if (descriptorEnd > Bin.Length)
                    continue;

                bool plausible = true;

                for (int j = 0; j < n; j++)
                {
                    int d = i + 4 + j * 4;
                    ushort size = ReadU16(Bin, d);
                    byte type = Bin[d + 2];
                    byte zero = Bin[d + 3];

                    if (zero != 0 || !IsKnownType(type))
                    {
                        plausible = false;
                        break;
                    }

                    if ((long)descriptorEnd + size > Bin.Length)
                    {
                        plausible = false;
                        break;
                    }
                }

                if (plausible)
                    return i;
            }

            return -1;
        }

        void ParseValueSpec(int p)
        {
            Values.Clear();

            uint n = ReadU32(Bin, p);
            if (n > 512)
                throw new InvalidDataException("Too many template values.");

            p += 4;

            for (ushort i = 0; i < n; i++)
            {
                ushort size = ReadU16(Bin, p);
                byte type = Bin[p + 2];

                Values[i] = new ValueSpec
                {
                    Id = i,
                    Size = size,
                    Type = type
                };

                p += 4;
            }

            int data = p;

            foreach (ValueSpec v in Values.Values)
            {
                if (data + v.Size > Bin.Length)
                    throw new InvalidDataException("Template value exceeds record.");

                v.Raw = new byte[v.Size];
                Buffer.BlockCopy(Bin, data, v.Raw, 0, v.Size);

                data += v.Size;
            }
        }

        int ParseFileElement(int p, int end, StringBuilder xml)
        {
            if (p >= end)
                return p;

            byte token = File[p++];

            if (token == 0x0F)
            {
                if (p + 3 > end) return end;
                p += 3;
                return ParseFileElement(p, end, xml);
            }

            if (token == 0x00)
                return p;

            if (token != 0x01 && token != 0x41)
                return p;

            // Template-definition element:
            // dependency id WORD, element byte length DWORD, then name.
            if (p + 6 > end)
                return end;

            ushort dependency = ReadU16(File, p); p += 2;
            uint elementLength = ReadU32(File, p); p += 4;

            string name = ReadName(File, ref p, end);

            xml.Append("<").Append(name).Append(">");

            while (p < end)
            {
                byte t = File[p];

                if (t == 0x02)
                {
                    p++;
                    break;
                }

                if (t == 0x04)
                {
                    p++;
                    xml.Append("</").Append(name).Append(">");
                    return p;
                }

                if (t == 0x0D || t == 0x0E)
                {
                    if (p + 4 > end) return end;

                    ushort id = ReadU16(File, p + 1);
                    p += 4;

                    xml.Append(RenderValue(id));
                    continue;
                }

                if (t == 0x05 || t == 0x45)
                {
                    byte valueType = File[p + 1];
                    p += 2;

                    if (valueType == 0x01)
                    {
                        ushort chars = ReadU16(File, p);
                        p += 2;
                        int bytes = chars * 2;

                        if (p + bytes > end) return end;

                        xml.Append(
                            Encoding.Unicode.GetString(
                                File, p, bytes));

                        p += bytes;
                    }
                    continue;
                }

                if (t == 0x01 || t == 0x41)
                {
                    p = ParseFileElement(p, end, xml);
                    continue;
                }

                if (t == 0x03)
                {
                    p++;
                    xml.Append("/>");
                    return p;
                }

                if (t == 0x00)
                    return p + 1;

                // Attribute token inside template.
                if (t == 0x06 || t == 0x46)
                {
                    p++;
                    if (p + 4 > end) return end;

                    uint nameOffset = ReadU32(File, p);
                    p += 4;

                    string attr = ReadNameAtChunkOffset(
                        nameOffset,
                        end);

                    xml.Append(" ").Append(attr).Append("=\"");

                    while (p < end)
                    {
                        byte at = File[p];

                        if (at == 0x0D || at == 0x0E)
                        {
                            ushort id = ReadU16(File, p + 1);
                            p += 4;
                            xml.Append(Escape(RenderValue(id)));
                            break;
                        }

                        if (at == 0x05 || at == 0x45)
                        {
                            byte vt = File[p + 1];
                            p += 2;

                            if (vt == 0x01)
                            {
                                ushort chars = ReadU16(File, p);
                                p += 2;
                                int bytes = chars * 2;

                                xml.Append(
                                    Escape(
                                        Encoding.Unicode.GetString(
                                            File, p, bytes)));

                                p += bytes;
                            }
                            else
                            {
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }

                    xml.Append("\"");

                    if (t == 0x06)
                    {
                        // Attribute list ends; caller will see token 0x02.
                    }

                    continue;
                }

                // Unknown token: move one byte to avoid infinite loop.
                p++;
            }

            return p;
        }

        int ParseElement(int p, StringBuilder xml, bool fromFile)
        {
            if (p >= Bin.Length)
                return p;

            byte token = Bin[p++];

            if (token == 0x0F)
            {
                if (p + 3 > Bin.Length) return Bin.Length;
                p += 3;
                return ParseElement(p, xml, fromFile);
            }

            if (token == 0x00)
                return p;

            if (token == 0x0C)
                return ParseTemplateInstance(p - 1, xml);

            if (token != 0x01 && token != 0x41)
                return p;

            // Non-template element form.
            if (p + 6 > Bin.Length)
                return Bin.Length;

            p += 2; // dependency
            p += 4; // element byte length

            string name = ReadName(Bin, ref p, Bin.Length);

            xml.Append("<").Append(name).Append(">");

            while (p < Bin.Length)
            {
                byte t = Bin[p];

                if (t == 0x02)
                {
                    p++;
                    continue;
                }

                if (t == 0x04)
                {
                    p++;
                    xml.Append("</").Append(name).Append(">");
                    return p;
                }

                if (t == 0x05 || t == 0x45)
                {
                    byte vt = Bin[p + 1];
                    p += 2;

                    if (vt == 0x01)
                    {
                        ushort chars = ReadU16(Bin, p);
                        p += 2;
                        int bytes = chars * 2;

                        if (p + bytes > Bin.Length)
                            return Bin.Length;

                        xml.Append(
                            Escape(
                                Encoding.Unicode.GetString(
                                    Bin, p, bytes)));

                        p += bytes;
                        continue;
                    }

                    continue;
                }

                if (t == 0x0D || t == 0x0E)
                {
                    ushort id = ReadU16(Bin, p + 1);
                    p += 4;
                    xml.Append(Escape(RenderValue(id)));
                    continue;
                }

                if (t == 0x01 || t == 0x41)
                {
                    p = ParseElement(p, xml, false);
                    continue;
                }

                p++;
            }

            return p;
        }

        string RenderValue(ushort id)
        {
            ValueSpec v;

            if (!Values.TryGetValue(id, out v))
                return "[SUBSTITUTION " + id + "]";

            switch (v.Type)
            {
                case 0x00:
                    return "";

                case 0x01:
                    return DecodeUtf16(v.Raw);

                case 0x02:
                    return Encoding.Default.GetString(v.Raw);

                case 0x03:
                    return ((sbyte)GetByte(v.Raw, 0)).ToString();

                case 0x04:
                    return GetByte(v.Raw, 0).ToString();

                case 0x05:
                    return GetI16(v.Raw).ToString();

                case 0x06:
                    return GetU16(v.Raw).ToString();

                case 0x07:
                    return GetI32(v.Raw).ToString();

                case 0x08:
                    return GetU32(v.Raw).ToString();

                case 0x09:
                    return GetI64(v.Raw).ToString();

                case 0x0A:
                    return GetU64(v.Raw).ToString();

                case 0x0B:
                    return BitConverter.ToSingle(Pad(v.Raw, 4), 0).ToString();

                case 0x0C:
                    return BitConverter.ToDouble(Pad(v.Raw, 8), 0).ToString();

                case 0x0D:
                    return v.Raw.Length >= 4 &&
                           GetU32(v.Raw) != 0
                        ? "true"
                        : "false";

                case 0x0F:
                    return FormatGuid(v.Raw);

                case 0x11:
                    if (v.Raw.Length >= 8)
                    {
                        try
                        {
                            return DateTime
                                .FromFileTimeUtc(GetI64(v.Raw))
                                .ToString("o");
                        }
                        catch { }
                    }
                    return Hex(v.Raw);

                case 0x14:
                    return "0x" + GetU32(v.Raw).ToString("X8");

                case 0x15:
                    return "0x" + GetU64(v.Raw).ToString("X16");

                default:
                    return Hex(v.Raw);
            }
        }

        static string DecodeUtf16(byte[] raw)
        {
            if (raw == null || raw.Length == 0)
                return "";

            return Encoding.Unicode.GetString(raw).TrimEnd('\0');
        }

        string ReadName(byte[] b, ref int p, int end)
        {
            // Name: hash WORD, char count WORD, UTF-16LE + null.
            // Some EVTX variants contain 4 bytes before hash; detect
            // the standard inline form first.
            if (p + 4 > end)
                return "Unknown";

            ushort hash = ReadU16(b, p);
            ushort chars = ReadU16(b, p + 2);

            if (chars > 0 && p + 4 + chars * 2 + 2 <= end)
            {
                p += 4;

                string name =
                    Encoding.Unicode.GetString(
                        b, p, chars * 2);

                p += chars * 2;

                if (p + 2 <= end)
                    p += 2;

                return name;
            }

            // Fallback for the 4-byte-prefixed representation.
            if (p + 8 <= end)
            {
                chars = ReadU16(b, p + 6);

                if (chars > 0 &&
                    p + 8 + chars * 2 + 2 <= end)
                {
                    p += 8;

                    string name =
                        Encoding.Unicode.GetString(
                            b, p, chars * 2);

                    p += chars * 2;

                    if (p + 2 <= end)
                        p += 2;

                    return name;
                }
            }

            return "Unknown";
        }

        string ReadNameAtChunkOffset(uint offset, int end)
        {
            int p = ChunkOffset + (int)offset;

            if (p < 0 || p >= File.Length)
                return "Unknown";

            return ReadName(File, ref p, Math.Min(File.Length, end));
        }

        static string Escape(string s)
        {
            if (s == null) return "";

            return s
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("\"", "&quot;");
        }

        static int FindByte(byte[] b, byte value, int start, int end)
        {
            for (int i = start; i < end && i < b.Length; i++)
                if (b[i] == value)
                    return i;

            return -1;
        }

        static bool IsKnownType(byte type)
        {
            byte t = (byte)(type & 0x7F);

            return t == 0x00 ||
                   t == 0x01 ||
                   t == 0x02 ||
                   t == 0x03 ||
                   t == 0x04 ||
                   t == 0x05 ||
                   t == 0x06 ||
                   t == 0x07 ||
                   t == 0x08 ||
                   t == 0x09 ||
                   t == 0x0A ||
                   t == 0x0B ||
                   t == 0x0C ||
                   t == 0x0D ||
                   t == 0x0E ||
                   t == 0x0F ||
                   t == 0x10 ||
                   t == 0x11 ||
                   t == 0x12 ||
                   t == 0x13 ||
                   t == 0x14 ||
                   t == 0x15 ||
                   t == 0x21;
        }

        static ushort ReadU16(byte[] b, int p)
        {
            return BitConverter.ToUInt16(b, p);
        }

        static int GetI16(byte[] b)
        {
            return BitConverter.ToInt16(Pad(b, 2), 0);
        }

        static uint GetU16(byte[] b)
        {
            return BitConverter.ToUInt16(Pad(b, 2), 0);
        }

        static int GetI32(byte[] b)
        {
            return BitConverter.ToInt32(Pad(b, 4), 0);
        }

        static uint GetU32(byte[] b)
        {
            return BitConverter.ToUInt32(Pad(b, 4), 0);
        }

        static long GetI64(byte[] b)
        {
            return BitConverter.ToInt64(Pad(b, 8), 0);
        }

        static ulong GetU64(byte[] b)
        {
            return BitConverter.ToUInt64(Pad(b, 8), 0);
        }

        static byte GetByte(byte[] b, int p)
        {
            return b != null && p < b.Length ? b[p] : (byte)0;
        }

        static byte[] Pad(byte[] b, int n)
        {
            byte[] x = new byte[n];

            if (b != null)
                Buffer.BlockCopy(b, 0, x, 0, Math.Min(n, b.Length));

            return x;
        }

        static string Hex(byte[] b)
        {
            StringBuilder s = new StringBuilder();

            if (b != null)
            {
                for (int i = 0; i < b.Length; i++)
                {
                    if (i > 0) s.Append(' ');
                    s.Append(b[i].ToString("X2"));
                }
            }

            return s.ToString();
        }

        static string FormatGuid(byte[] b)
        {
            if (b == null || b.Length != 16)
                return Hex(b);

            try
            {
                byte[] x = (byte[])b.Clone();

                return new Guid(x).ToString("B");
            }
            catch
            {
                return Hex(b);
            }
        }
    }

    class ValueSpec
    {
        public ushort Id;
        public ushort Size;
        public byte Type;
        public byte[] Raw;
    }
}
