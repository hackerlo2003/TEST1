C# .NET Framework 4.7.2 port of xml2evtx.py.

Important fix: the Python implementation uses the LAST 0x2a2a0000 event-record signature when patching chunk offset 0x2c. Earlier C# versions used the first signature, producing an invalid EVTX.

Build:
csc /target:exe /out:Xml2Evtx.exe Xml2Evtx.cs

Run:
Xml2Evtx.exe -x file.xml
