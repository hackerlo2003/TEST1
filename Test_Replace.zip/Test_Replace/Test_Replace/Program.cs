﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Test_Replace
{
    class Program
    {
        static void Main(string[] args)
        {

            string filepath = @"C:\Windows\Temp\output.xml";
            string text = File.ReadAllText(filepath);
            string header = "<Event xmlns='http://schemas.microsoft.com/win/2004/08/events/event'>";
            string[] lines = text.Split(new string[] { header }, StringSplitOptions.None);

            string result = "";

            string eventId = "4625";
            string check = $"<EventID>{eventId}</EventID>";
            int count = 0;
            foreach (string line in lines)
            {
                count++;
                if (count == 1)
                {
                    result = "\n";
                    continue;
                }
                if (line.Contains(check))
                {
                    result += header + line;
                    result = Regex.Replace(result, "<Data Name='TargetUserName'>.*?</Data>", "<Data Name='TargetUserName'>ANONYMOUS LOGON</Data>", RegexOptions.Singleline);
                    result = Regex.Replace(result, "<Data Name='TargetDomainName'>.*?</Data> ", "<Data Name='TargetDomainName'>NT AUTHORITY</Data> ", RegexOptions.Singleline);
                    result = Regex.Replace(result, "<Data Name='LogonType'>.*?</Data>", "<Data Name='LogonType'>2</Data>", RegexOptions.Singleline);
                    result = Regex.Replace(result, "<Data Name='IpAddress'>.*?</Data>", "<Data Name='IpAddress'>127.0.0.1</Data>", RegexOptions.Singleline);
                    result = Regex.Replace(result, "<Data Name='IpPort'>.*?</Data>", "<Data Name='IpPort'>76767</Data>", RegexOptions.Singleline);
                    result += "\n";
                    continue;
                }
                result += header + line + "\n";
              
            }

            File.WriteAllText(filepath, result);
            Console.WriteLine("Done!");

        }
    }
}
