using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace EvtxParser
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath =
                args.Length > 0
                    ? args[0]
                    : @"C:\Windows\System32\winevt\Logs\Security.evtx";

            Console.WriteLine("Is64BitProcess: " +
                              Environment.Is64BitProcess);

            Console.WriteLine("Is64BitOperatingSystem: " +
                              Environment.Is64BitOperatingSystem);

            Console.WriteLine();

            if (!File.Exists(filePath))
            {
                Console.WriteLine(
                    "[-] File not found: " + filePath);

                return;
            }

            try
            {
                EvtxFile evtx =
                    new EvtxFile(filePath);

                evtx.Parse();

                Console.WriteLine();
                Console.WriteLine(
                    "========================================");

                Console.WriteLine(
                    "[+] Parsing finished.");

                Console.WriteLine(
                    "[+] Chunks: " +
                    evtx.Chunks.Count);

                Console.WriteLine(
                    "[+] Records: " +
                    evtx.TotalRecords);

                Console.WriteLine();
                Console.WriteLine(
                    "[+] READ ONLY");

                Console.WriteLine(
                    "[+] No bytes were modified.");

                Console.WriteLine(
                    "[+] No file was written.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(
                    "[-] Error:");

                Console.WriteLine(
                    ex.ToString());
            }
        }
    }

    class EvtxFile
    {
        public byte[] Data;

        public List<EvtxChunk> Chunks =
            new List<EvtxChunk>();

        public int TotalRecords
        {
            get
            {
                int count = 0;

                foreach (EvtxChunk chunk in Chunks)
                {
                    count += chunk.Records.Count;
                }

                return count;
            }
        }

        public EvtxFile(string path)
        {
            Console.WriteLine("[+] Reading:");
            Console.WriteLine("    " + path);

            Data = File.ReadAllBytes(path);

            Console.WriteLine();
            Console.WriteLine(
                "[+] File size: " +
                Data.Length +
                " bytes");
        }

        public void Parse()
        {
            if (Data.Length < 4096)
            {
                Console.WriteLine(
                    "[-] File is smaller than EVTX header.");

                return;
            }

            if (!CheckFileHeader())
            {
                Console.WriteLine(
                    "[-] Invalid EVTX file.");

                return;
            }

            Console.WriteLine(
                "[+] EVTX File Header: OK");

            const int FILE_HEADER_SIZE = 4096;
            const int CHUNK_SIZE = 65536;

            int offset = FILE_HEADER_SIZE;
            int chunkIndex = 0;

            while (offset + CHUNK_SIZE <= Data.Length)
            {
                Console.WriteLine();
                Console.WriteLine(
                    "========================================");

                Console.WriteLine(
                    "CHUNK #" + chunkIndex);

                Console.WriteLine(
                    "Offset: " + offset);

                EvtxChunk chunk =
                    new EvtxChunk(
                        Data,
                        offset,
                        chunkIndex);

                if (!chunk.Parse())
                {
                    Console.WriteLine(
                        "[-] Chunk parsing failed.");

                    break;
                }

                Chunks.Add(chunk);

                offset += CHUNK_SIZE;
                chunkIndex++;
            }
        }

        private bool CheckFileHeader()
        {
            byte[] magic =
                Encoding.ASCII.GetBytes("ElfFile");

            for (int i = 0;
                 i < magic.Length;
                 i++)
            {
                if (Data[i] != magic[i])
                    return false;
            }

            return true;
        }
    }

    class EvtxChunk
    {
        private byte[] Data;
        private int Offset;
        private int Index;

        public List<EvtxRecord> Records =
            new List<EvtxRecord>();

        public EvtxChunk(
            byte[] data,
            int offset,
            int index)
        {
            Data = data;
            Offset = offset;
            Index = index;
        }

        public bool Parse()
        {
            const int CHUNK_SIZE = 65536;

            if (Offset + CHUNK_SIZE >
                Data.Length)
            {
                return false;
            }

            string signature =
                Encoding.ASCII.GetString(
                    Data,
                    Offset,
                    7);

            if (signature != "ElfChnk")
            {
                Console.WriteLine(
                    "[-] Invalid chunk signature.");

                return false;
            }

            Console.WriteLine(
                "[+] Chunk signature: ElfChnk");

            ulong firstRecordId =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 8);

            ulong lastRecordId =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 16);

            Console.WriteLine(
                "[+] First Record ID: " +
                firstRecordId);

            Console.WriteLine(
                "[+] Last Record ID: " +
                lastRecordId);

            int searchStart =
                Offset + 512;

            int searchEnd =
                Offset + CHUNK_SIZE;

            int recordIndex = 0;

            for (int pos = searchStart;
                 pos + 8 <= searchEnd;
                 pos++)
            {
                if (!IsRecordSignature(pos))
                    continue;

                EvtxRecord record =
                    new EvtxRecord(
                        Data,
                        pos,
                        Index,
                        recordIndex);

                if (record.Parse())
                {
                    Records.Add(record);
                    recordIndex++;

                    if (record.RecordSize >= 24)
                    {
                        pos +=
                            (int)record.RecordSize - 1;
                    }
                }
            }

            Console.WriteLine();
            Console.WriteLine(
                "[+] Records found: " +
                Records.Count);

            return true;
        }

        private bool IsRecordSignature(
            int position)
        {
            if (position + 4 >
                Data.Length)
            {
                return false;
            }

            return
                Data[position] == 0x2A &&
                Data[position + 1] == 0x2A &&
                Data[position + 2] == 0x00 &&
                Data[position + 3] == 0x00;
        }
    }

    class EvtxRecord
    {
        private byte[] Data;

        public int Offset;
        public int ChunkIndex;
        public int Index;
        public uint RecordSize;
        public ulong RecordId;
        public ulong Timestamp;
        public int BinXmlSize;
        public byte[] BinXml;

        public EvtxRecord(
            byte[] data,
            int offset,
            int chunkIndex,
            int index)
        {
            Data = data;
            Offset = offset;
            ChunkIndex = chunkIndex;
            Index = index;
        }

        public bool Parse()
        {
            if (Offset + 24 >
                Data.Length)
            {
                return false;
            }

            if (!IsSignature())
                return false;

            RecordSize =
                BitConverter.ToUInt32(
                    Data,
                    Offset + 4);

            RecordId =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 8);

            Timestamp =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 16);

            if (RecordSize < 24)
                return false;

            if (RecordSize > 65536)
                return false;

            if (Offset + RecordSize >
                Data.Length)
            {
                return false;
            }

            BinXmlSize =
                (int)RecordSize -
                24 -
                4;

            if (BinXmlSize <= 0)
                return false;

            BinXml =
                new byte[BinXmlSize];

            Buffer.BlockCopy(
                Data,
                Offset + 24,
                BinXml,
                0,
                BinXmlSize);

            PrintRecord();

            ParseBinXmlText();

            return true;
        }

        private void ParseBinXmlText()
        {
            Console.WriteLine();
            Console.WriteLine(
                "  --------------------------------------");

            Console.WriteLine(
                "  BINXML TEXT VALUES");

            Console.WriteLine(
                "  BinXML absolute offset: " +
                (Offset + 24));

            Console.WriteLine(
                "  BinXML size: " +
                BinXmlSize);

            Console.WriteLine();

            List<TextValue> values =
                ExtractUtf16Values(BinXml);

            if (values.Count == 0)
            {
                Console.WriteLine(
                    "  [-] No readable UTF-16 values found.");

                return;
            }

            Console.WriteLine(
                "  [+] Text values found: " +
                values.Count);

            Console.WriteLine();

            foreach (TextValue value in values)
            {
                Console.WriteLine(
                    "  --------------------------------------");

                Console.WriteLine(
                    "  BinXML offset : " +
                    value.Offset);

                Console.WriteLine(
                    "  File offset   : " +
                    (Offset + 24 + value.Offset));

                Console.WriteLine(
                    "  Byte length   : " +
                    value.ByteLength);

                Console.WriteLine(
                    "  Text          : " +
                    value.Text);
            }
        }

        private List<TextValue> ExtractUtf16Values(
            byte[] data)
        {
            List<TextValue> result =
                new List<TextValue>();

            int i = 0;

            while (i + 4 <= data.Length)
            {
                if (IsPrintableUtf16(
                    data[i],
                    data[i + 1]))
                {
                    int start = i;

                    StringBuilder text =
                        new StringBuilder();

                    while (i + 1 < data.Length)
                    {
                        ushort value =
                            BitConverter.ToUInt16(
                                data,
                                i);

                        if (value >= 32 &&
                            value <= 126)
                        {
                            text.Append(
                                (char)value);

                            i += 2;
                        }
                        else
                        {
                            break;
                        }
                    }

                    if (text.Length >= 3)
                    {
                        TextValue item =
                            new TextValue();

                        item.Offset = start;
                        item.ByteLength =
                            text.Length * 2;

                        item.Text =
                            text.ToString();

                        result.Add(item);
                    }

                    if (i == start)
                        i += 2;

                    continue;
                }

                i++;
            }

            return result;
        }

        private bool IsPrintableUtf16(
            byte low,
            byte high)
        {
            return
                low >= 32 &&
                low <= 126 &&
                high == 0x00;
        }

        private void PrintRecord()
        {
            Console.WriteLine();
            Console.WriteLine(
                "Record #" + Index);

            Console.WriteLine(
                "  File offset : " + Offset);

            Console.WriteLine(
                "  Record size : " + RecordSize);

            Console.WriteLine(
                "  Record ID   : " + RecordId);

            Console.WriteLine(
                "  BinXML size : " + BinXmlSize);

            try
            {
                DateTime time =
                    DateTime.FromFileTimeUtc(
                        (long)Timestamp);

                Console.WriteLine(
                    "  Timestamp   : " +
                    time.ToString(
                        "yyyy-MM-dd HH:mm:ss.fffffff"));
            }
            catch
            {
                Console.WriteLine(
                    "  Timestamp   : invalid");
            }
        }

        private bool IsSignature()
        {
            return
                Data[Offset] == 0x2A &&
                Data[Offset + 1] == 0x2A &&
                Data[Offset + 2] == 0x00 &&
                Data[Offset + 3] == 0x00;
        }
    }

    class TextValue
    {
        public int Offset;
        public int ByteLength;
        public string Text;
    }
}
