xml2evtx - C# / .NET Framework 4.7.2

This is a C# port of JPCERTCC/xml2evtx.py.

Build in a Visual Studio Developer Command Prompt:
  csc /target:exe /out:Xml2Evtx.exe Xml2Evtx.cs

Usage:
  Xml2Evtx.exe -x input.xml
  Xml2Evtx.exe -x input.xml -v
  Xml2Evtx.exe -t

The EVTX chunk header is 0x80 bytes. In particular, the free_space_offset
field at offset 0x30 must be present; omitting it shifts the remaining fields
and causes an IndexOutOfRangeException when the checksum is patched.
