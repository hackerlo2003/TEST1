using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

class Program
{
    // Windows Event Log native API
    [DllImport("wevtapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern IntPtr EvtQuery(
        IntPtr session,
        string path,
        string query,
        int flags);

    [DllImport("wevtapi.dll", SetLastError = true)]
    static extern bool EvtNext(
        IntPtr resultSet,
        int eventArraySize,
        IntPtr[] eventArray,
        int timeout,
        int flags,
        out int returned);

    [DllImport("wevtapi.dll", SetLastError = true)]
    static extern bool EvtRender(
        IntPtr context,
        IntPtr fragment,
        int flags,
        int bufferSize,
        IntPtr buffer,
        out int bufferUsed,
        out int propertyCount);

    [DllImport("wevtapi.dll", SetLastError = true)]
    static extern bool EvtClose(
        IntPtr objectHandle);

    const int EvtQueryFilePath = 0x0001;
    const int EvtQueryForwardDirection = 0x0100;
    const int EvtRenderEventXml = 1;

    static void Main(string[] args)
    {
        string filePath = args.Length > 0
            ? args[0]
            : @"C:\Windows\System32\winevt\Logs\Security.evtx";

        if (!File.Exists(filePath))
        {
            Console.WriteLine("[-] File not found: " + filePath);
            return;
        }

        Console.WriteLine("[+] File: " + filePath);
        Console.WriteLine("[+] File size: " +
                          new FileInfo(filePath).Length +
                          " bytes");
        Console.WriteLine();

        IntPtr query = IntPtr.Zero;

        try
        {
            query = EvtQuery(
                IntPtr.Zero,
                filePath,
                "*",
                EvtQueryFilePath | EvtQueryForwardDirection);

            if (query == IntPtr.Zero)
            {
                PrintLastError("EvtQuery");
                return;
            }

            IntPtr[] events = new IntPtr[1];
            int returned;

            if (!EvtNext(
                query,
                1,
                events,
                0,
                0,
                out returned))
            {
                PrintLastError("EvtNext");
                return;
            }

            if (returned == 0 || events[0] == IntPtr.Zero)
            {
                Console.WriteLine("[-] No record found.");
                return;
            }

            IntPtr eventHandle = events[0];

            try
            {
                Console.WriteLine("========================================");
                Console.WriteLine("RECORD #0");
                Console.WriteLine("========================================");

                /*
                 * EvtRender with EvtRenderEventXml asks Windows
                 * to decode the BinXML and render the complete
                 * logical event as XML.
                 */
                string xml = RenderEventXml(eventHandle);

                if (String.IsNullOrEmpty(xml))
                {
                    Console.WriteLine("[-] Could not render event.");
                    return;
                }

                PrintRecordHeader(xml);

                Console.WriteLine();
                Console.WriteLine("========================================");
                Console.WriteLine("PARSED EVENT / BINXML");
                Console.WriteLine("========================================");
                Console.WriteLine(xml);
            }
            finally
            {
                EvtClose(eventHandle);
            }
        }
        finally
        {
            if (query != IntPtr.Zero)
                EvtClose(query);
        }
    }

    static string RenderEventXml(IntPtr eventHandle)
    {
        int bufferUsed;
        int propertyCount;

        /*
         * First call: obtain required buffer size.
         */
        EvtRender(
            IntPtr.Zero,
            eventHandle,
            EvtRenderEventXml,
            0,
            IntPtr.Zero,
            out bufferUsed,
            out propertyCount);

        int error = Marshal.GetLastWin32Error();

        /*
         * ERROR_INSUFFICIENT_BUFFER = 122.
         */
        if (bufferUsed <= 0 && error != 122)
        {
            PrintLastError("EvtRender(size)");
            return null;
        }

        IntPtr buffer =
            Marshal.AllocHGlobal(bufferUsed);

        try
        {
            if (!EvtRender(
                IntPtr.Zero,
                eventHandle,
                EvtRenderEventXml,
                bufferUsed,
                buffer,
                out bufferUsed,
                out propertyCount))
            {
                PrintLastError("EvtRender");
                return null;
            }

            return Marshal.PtrToStringUni(buffer);
        }
        finally
        {
            Marshal.FreeHGlobal(buffer);
        }
    }

    static void PrintRecordHeader(string xml)
    {
        /*
         * The rendered XML contains the logical values.
         * We print the most important fields without
         * implementing a second XML parser.
         */

        string provider =
            GetXmlValue(xml, "Provider", "Name");

        string eventId =
            GetXmlElementValue(xml, "EventID");

        string level =
            GetXmlElementValue(xml, "Level");

        string task =
            GetXmlElementValue(xml, "Task");

        string opcode =
            GetXmlElementValue(xml, "Opcode");

        string keywords =
            GetXmlElementValue(xml, "Keywords");

        string computer =
            GetXmlElementValue(xml, "Computer");

        string recordId =
            GetXmlElementValue(xml, "EventRecordID");

        string time =
            GetXmlValue(xml, "TimeCreated", "SystemTime");

        Console.WriteLine(
            "Provider     : " + provider);

        Console.WriteLine(
            "Event ID     : " + eventId);

        Console.WriteLine(
            "Level        : " + level);

        Console.WriteLine(
            "Task         : " + task);

        Console.WriteLine(
            "Opcode       : " + opcode);

        Console.WriteLine(
            "Keywords     : " + keywords);

        Console.WriteLine(
            "Time         : " + time);

        Console.WriteLine(
            "EventRecordID: " + recordId);

        Console.WriteLine(
            "Computer     : " + computer);
    }

    static string GetXmlElementValue(
        string xml,
        string elementName)
    {
        string open =
            "<" + elementName;

        int start =
            xml.IndexOf(
                open,
                StringComparison.OrdinalIgnoreCase);

        if (start < 0)
            return "";

        int tagEnd =
            xml.IndexOf(
                ">",
                start);

        if (tagEnd < 0)
            return "";

        int close =
            xml.IndexOf(
                "</" + elementName + ">",
                tagEnd + 1,
                StringComparison.OrdinalIgnoreCase);

        if (close < 0)
            return "";

        return xml.Substring(
                tagEnd + 1,
                close - tagEnd - 1)
            .Trim();
    }

    static string GetXmlValue(
        string xml,
        string elementName,
        string attributeName)
    {
        string open =
            "<" + elementName;

        int start =
            xml.IndexOf(
                open,
                StringComparison.OrdinalIgnoreCase);

        if (start < 0)
            return "";

        int end =
            xml.IndexOf(
                ">",
                start);

        if (end < 0)
            return "";

        string tag =
            xml.Substring(
                start,
                end - start + 1);

        string key =
            attributeName + "=\"";

        int valueStart =
            tag.IndexOf(
                key,
                StringComparison.OrdinalIgnoreCase);

        if (valueStart < 0)
            return "";

        valueStart += key.Length;

        int valueEnd =
            tag.IndexOf(
                "\"",
                valueStart);

        if (valueEnd < 0)
            return "";

        return tag.Substring(
            valueStart,
            valueEnd - valueStart);
    }

    static void PrintLastError(string api)
    {
        int error =
            Marshal.GetLastWin32Error();

        Console.WriteLine(
            "[-] " +
            api +
            " failed. Win32 error: " +
            error);
    }
}
