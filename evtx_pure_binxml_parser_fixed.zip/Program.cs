using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Globalization;

namespace EvtxPureBinXml
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = args.Length > 0
                ? args[0]
                : @"test.evtx";

            if (!File.Exists(path))
            {
                Console.WriteLine("[-] File not found: " + path);
                return;
            }

            byte[] file = File.ReadAllBytes(path);

            Console.WriteLine("[+] File size: " + file.Length + " bytes");

            EvtxParser parser = new EvtxParser(file);

            if (!parser.ParseFirstRecord())
            {
                Console.WriteLine("[-] Failed to parse first record.");
                return;
            }
        }
    }

    class EvtxParser
    {
        private readonly byte[] FileData;

        private const int FileHeaderSize = 4096;
        private const int ChunkSize = 65536;
        private const int ChunkHeaderSize = 512;

        public EvtxParser(byte[] data)
        {
            FileData = data;
        }

        public bool ParseFirstRecord()
        {
            if (FileData.Length < FileHeaderSize + ChunkHeaderSize)
                return false;

            if (Encoding.ASCII.GetString(FileData, 0, 7) != "ElfFile")
                return false;

            int chunkOffset = FileHeaderSize;

            if (Encoding.ASCII.GetString(
                    FileData,
                    chunkOffset,
                    7) != "ElfChnk")
            {
                return false;
            }

            int recordOffset =
                FindFirstRecord(
                    chunkOffset + ChunkHeaderSize,
                    chunkOffset + ChunkSize);

            if (recordOffset < 0)
                return false;

            uint recordSize =
                ReadU32(recordOffset + 4);

            ulong recordId =
                ReadU64(recordOffset + 8);

            ulong timestamp =
                ReadU64(recordOffset + 16);

            if (recordSize < 28 ||
                recordOffset + recordSize > FileData.Length)
            {
                return false;
            }

            int binXmlSize =
                checked((int)recordSize - 24 - 4);

            byte[] binXml =
                new byte[binXmlSize];

            Buffer.BlockCopy(
                FileData,
                recordOffset + 24,
                binXml,
                0,
                binXmlSize);

            Console.WriteLine();
            Console.WriteLine("========================================");
            Console.WriteLine("RECORD");
            Console.WriteLine("========================================");
            Console.WriteLine("Record Size : " + recordSize);
            Console.WriteLine("Record ID   : " + recordId);
            Console.WriteLine("BinXML Size : " + binXmlSize);

            try
            {
                DateTime time =
                    DateTime.FromFileTimeUtc((long)timestamp);

                Console.WriteLine(
                    "Time        : " +
                    time.ToString(
                        "yyyy-MM-dd HH:mm:ss.fffffff",
                        CultureInfo.InvariantCulture) +
                    " UTC");
            }
            catch
            {
                Console.WriteLine("Time        : invalid");
            }

            BinXmlParser bx =
                new BinXmlParser(
                    binXml,
                    FileData,
                    chunkOffset);

            string xml = bx.ParseDocument();

            Console.WriteLine();
            Console.WriteLine("========================================");
            Console.WriteLine("BINXML PARSED");
            Console.WriteLine("========================================");

            if (xml == null)
            {
                Console.WriteLine(
                    "[-] BinXML parser failed.");
                return false;
            }

            Console.WriteLine(xml);

            return true;
        }

        private int FindFirstRecord(
            int start,
            int end)
        {
            for (int p = start;
                 p + 8 <= end;
                 p++)
            {
                if (FileData[p] == 0x2A &&
                    FileData[p + 1] == 0x2A &&
                    FileData[p + 2] == 0x00 &&
                    FileData[p + 3] == 0x00)
                {
                    uint size =
                        ReadU32(p + 4);

                    if (size >= 28 &&
                        p + size <= FileData.Length)
                    {
                        return p;
                    }
                }
            }

            return -1;
        }

        private ushort ReadU16(int p)
        {
            return BitConverter.ToUInt16(FileData, p);
        }

        private uint ReadU32(int p)
        {
            return BitConverter.ToUInt32(FileData, p);
        }

        private ulong ReadU64(int p)
        {
            return BitConverter.ToUInt64(FileData, p);
        }
    }

    class BinXmlParser
    {
        private readonly byte[] Bin;
        private readonly byte[] FileData;
        private readonly int ChunkOffset;

        private const byte EOF = 0x00;
        private const byte OpenElement = 0x01;
        private const byte CloseStart = 0x02;
        private const byte CloseEmpty = 0x03;
        private const byte EndElement = 0x04;
        private const byte ValueText = 0x05;
        private const byte ValueTextMore = 0x45;
        private const byte Attribute = 0x06;
        private const byte AttributeMore = 0x46;
        private const byte TemplateInstance = 0x0C;
        private const byte NormalSubstitution = 0x0D;
        private const byte OptionalSubstitution = 0x0E;
        private const byte FragmentHeader = 0x0F;

        private List<ValueSpec> Values =
            new List<ValueSpec>();

        // Binary readers for this parser's own BinXML buffer.
        private ushort ReadU16(int p)
        {
            return BitConverter.ToUInt16(Bin, p);
        }

        private uint ReadU32(int p)
        {
            return BitConverter.ToUInt32(Bin, p);
        }

        private ulong ReadU64(int p)
        {
            return BitConverter.ToUInt64(Bin, p);
        }

        public BinXmlParser(
            byte[] binXml,
            byte[] fileData,
            int chunkOffset)
        {
            Bin = binXml;
            FileData = fileData;
            ChunkOffset = chunkOffset;
        }

        public string ParseDocument()
        {
            if (Bin.Length < 4)
                return null;

            if (Bin[0] != FragmentHeader)
                return null;

            if (Bin[1] != 1 ||
                Bin[2] != 1)
                return null;

            int p = 4;

            /*
             * The sample starts with:
             *
             * 0F 01 01 00
             * 0C
             * TemplateDefinition
             */

            if (p >= Bin.Length ||
                Bin[p] != TemplateInstance)
            {
                return null;
            }

            TemplateDefinition def =
                ReadTemplateDefinition(p);

            if (def == null)
                return null;

            Values =
                ReadValueSpecs(def.ValueSpecOffset);

            if (Values == null)
                return null;

            Element root =
                ParseElement(
                    def.TemplateFragmentOffset,
                    def.TemplateEndOffset,
                    true);

            if (root == null)
                return null;

            StringBuilder output =
                new StringBuilder();

            RenderElement(
                root,
                output,
                0);

            return output.ToString();
        }

        private TemplateDefinition ReadTemplateDefinition(
            int templateTokenOffset)
        {
            /*
             * TemplateInstance:
             *
             * 0  : 0C
             * 1  : version
             * 5  : unknown/template id
             * 9  : template data offset
             * 13 : next template offset
             * 17 : GUID
             * 33 : data size
             *
             * The 33 bytes are after the token.
             */

            int p = templateTokenOffset;

            if (p + 34 > Bin.Length)
                return null;

            int dataSize =
                checked((int)ReadU32(
                    p + 30));

            int fragmentOffset =
                p + 34;

            int templateEnd =
                fragmentOffset + dataSize;

            if (templateEnd > Bin.Length ||
                templateEnd <= fragmentOffset)
            {
                return null;
            }

            if (Bin[fragmentOffset] != FragmentHeader)
                return null;

            /*
             * The EOF token terminates the template
             * definition. The value-spec starts immediately
             * after that EOF.
             */

            if (Bin[templateEnd - 1] != EOF)
            {
                Console.WriteLine(
                    "[!] Template definition does not end in EOF.");
            }

            return new TemplateDefinition
            {
                TemplateFragmentOffset =
                    fragmentOffset,

                TemplateEndOffset =
                    templateEnd,

                ValueSpecOffset =
                    templateEnd
            };
        }

        private List<ValueSpec> ReadValueSpecs(
            int p)
        {
            if (p + 4 > Bin.Length)
                return null;

            uint count =
                ReadU32(p);

            p += 4;

            if (count > 4096)
                return null;

            List<ValueSpec> list =
                new List<ValueSpec>();

            for (uint i = 0; i < count; i++)
            {
                if (p + 4 > Bin.Length)
                    return null;

                ushort size =
                    ReadU16(p);

                byte type =
                    Bin[p + 2];

                p += 4;

                list.Add(
                    new ValueSpec
                    {
                        Size = size,
                        Type = type
                    });
            }

            foreach (ValueSpec spec in list)
            {
                if (p + spec.Size > Bin.Length)
                    return null;

                spec.DataOffset = p;

                p += spec.Size;
            }

            return list;
        }

        private Element ParseElement(
            int p,
            int limit,
            bool templateMode)
        {
            if (p >= limit)
                return null;

            byte token =
                Bin[p];

            if (token != OpenElement &&
                token != 0x41)
            {
                Console.WriteLine(
                    "[!] Expected element at 0x" +
                    p.ToString("X"));

                return null;
            }

            int q = p + 1;

            ushort dependency =
                0xFFFF;

            if (templateMode)
            {
                if (q + 2 > limit)
                    return null;

                dependency =
                    ReadU16(q);

                q += 2;
            }

            if (q + 4 > limit)
                return null;

            uint elementByteLength =
                ReadU32(q);

            q += 4;

            /*
             * The element byte length counts everything
             * after the DWORD itself through its final
             * close/end token.
             */

            int elementEnd =
                checked(q + (int)elementByteLength);

            if (elementEnd > limit ||
                elementEnd > Bin.Length)
            {
                return null;
            }

            /*
             * In EVTX records the next DWORD is the name
             * offset, followed by the inline Name structure.
             *
             * The name offset is relative to the beginning
             * of the chunk.
             */

            if (q + 4 > elementEnd)
                return null;

            uint nameOffset =
                ReadU32(q);

            q += 4;

            string name =
                ReadInlineName(
                    ref q,
                    elementEnd,
                    nameOffset);

            if (name == null)
                return null;

            Element element =
                new Element
                {
                    Name = name,
                    Dependency = dependency
                };

            /*
             * Token 0x41 has an attribute list.
             */

            if (token == 0x41)
            {
                if (q + 4 > elementEnd)
                    return null;

                uint attributeByteLength =
                    ReadU32(q);

                q += 4;

                int attributeEnd =
                    checked(q +
                            (int)attributeByteLength);

                if (attributeEnd > elementEnd)
                    return null;

                while (q < attributeEnd)
                {
                    byte at =
                        Bin[q];

                    if (at != Attribute &&
                        at != AttributeMore)
                    {
                        return null;
                    }

                    q++;

                    if (q + 4 > attributeEnd)
                        return null;

                    uint attrNameOffset =
                        ReadU32(q);

                    q += 4;

                    string attrName =
                        ReadInlineName(
                            ref q,
                            attributeEnd,
                            attrNameOffset);

                    if (attrName == null)
                        return null;

                    AttributeNode attr =
                        new AttributeNode
                        {
                            Name = attrName
                        };

                    while (q < attributeEnd)
                    {
                        byte ct =
                            Bin[q];

                        if (ct == Attribute ||
                            ct == AttributeMore)
                        {
                            break;
                        }

                        ValuePart part;

                        if (!ReadContentValue(
                                ref q,
                                attributeEnd,
                                out part))
                        {
                            return null;
                        }

                        attr.Values.Add(part);
                    }

                    element.Attributes.Add(attr);
                }

                q = attributeEnd;
            }

            /*
             * CloseStartElementToken.
             */

            if (q >= elementEnd)
                return null;

            if (Bin[q] == CloseStart)
            {
                q++;
            }
            else if (Bin[q] == CloseEmpty)
            {
                q++;

                element.IsEmpty = true;

                return element;
            }
            else
            {
                return null;
            }

            /*
             * Element content.
             */

            while (q < elementEnd)
            {
                byte ct =
                    Bin[q];

                if (ct == EndElement)
                {
                    q++;

                    return element;
                }

                if (ct == EOF)
                {
                    return element;
                }

                if (ct == OpenElement ||
                    ct == 0x41)
                {
                    Element child =
                        ParseElement(
                            q,
                            elementEnd,
                            templateMode);

                    if (child == null)
                        return null;

                    element.Children.Add(child);

                    /*
                     * Recalculate child end from its
                     * encoded element length.
                     */

                    q = FindElementEnd(
                        q,
                        elementEnd,
                        templateMode);

                    continue;
                }

                ValuePart part;

                if (!ReadContentValue(
                        ref q,
                        elementEnd,
                        out part))
                {
                    /*
                     * Some template definitions contain
                     * nested markup that is not a value.
                     */
                    return null;
                }

                element.Values.Add(part);
            }

            return null;
        }

        private int FindElementEnd(
            int p,
            int limit,
            bool templateMode)
        {
            int q = p + 1;

            if (templateMode)
                q += 2;

            if (q + 4 > limit)
                return limit;

            uint length =
                ReadU32(q);

            q += 4;

            return checked(
                q + (int)length);
        }

        private bool ReadContentValue(
            ref int p,
            int limit,
            out ValuePart part)
        {
            part = null;

            if (p >= limit)
                return false;

            byte token =
                Bin[p];

            if (token == NormalSubstitution ||
                token == OptionalSubstitution)
            {
                if (p + 4 > limit)
                    return false;

                ushort id =
                    ReadU16(p + 1);

                byte expectedType =
                    Bin[p + 3];

                p += 4;

                part =
                    new ValuePart
                    {
                        IsSubstitution = true,
                        Optional =
                            token ==
                            OptionalSubstitution,
                        SubstitutionId = id,
                        ExpectedType = expectedType
                    };

                return true;
            }

            if (token == ValueText ||
                token == ValueTextMore)
            {
                if (p + 4 > limit)
                    return false;

                byte valueType =
                    Bin[p + 1];

                if (valueType != 0x01)
                    return false;

                ushort charCount =
                    ReadU16(p + 2);

                int bytes =
                    checked(charCount * 2);

                if (p + 4 + bytes > limit)
                    return false;

                string text =
                    Encoding.Unicode.GetString(
                        Bin,
                        p + 4,
                        bytes);

                p += 4 + bytes;

                part =
                    new ValuePart
                    {
                        IsSubstitution = false,
                        LiteralText =
                            text.TrimEnd('\0')
                    };

                return true;
            }

            return false;
        }

        private string ReadInlineName(
            ref int p,
            int limit,
            uint nameOffset)
        {
            /*
             * Name layout in EVTX record BinXML:
             *
             * 4 bytes unknown/name-reference data
             * 2 bytes hash
             * 2 bytes character count
             * UTF-16LE characters + terminating NULL
             *
             * The name offset points to the same name
             * in the chunk string/name area.
             *
             * For robustness, parse the inline copy first.
             */

            if (p + 8 > limit)
                return null;

            p += 4;

            ushort hash =
                ReadU16(p);

            ushort charCount =
                ReadU16(p + 2);

            p += 4;

            int byteCount =
                checked((charCount + 1) * 2);

            if (p + byteCount > limit)
                return null;

            string name =
                Encoding.Unicode.GetString(
                    Bin,
                    p,
                    charCount * 2);

            p += byteCount;

            if (name.Length > 0)
                return name;

            /*
             * Fallback to the chunk-relative name offset.
             */

            long absolute =
                (long)ChunkOffset +
                nameOffset;

            if (absolute >= 0 &&
                absolute + 8 <= FileData.Length)
            {
                int np =
                    (int)absolute;

                ushort n =
                    BitConverter.ToUInt16(
                        FileData,
                        np + 6);

                int size =
                    checked((n + 1) * 2);

                if (np + 8 + size <=
                    FileData.Length)
                {
                    return Encoding.Unicode.GetString(
                        FileData,
                        np + 8,
                        n * 2);
                }
            }

            return null;
        }

        private void RenderElement(
            Element element,
            StringBuilder output,
            int depth)
        {
            /*
             * Dependency ID:
             * if the referenced value is NULL,
             * the element is omitted.
             */

            if (element.Dependency != 0xFFFF &&
                IsNullValue(element.Dependency))
            {
                return;
            }

            string indent =
                new string(' ', depth * 2);

            output.Append(indent);
            output.Append("<");
            output.Append(EscapeXml(element.Name));

            foreach (AttributeNode attr in
                     element.Attributes)
            {
                output.Append(" ");
                output.Append(
                    EscapeXml(attr.Name));
                output.Append("=\"");

                foreach (ValuePart part in attr.Values)
                {
                    output.Append(
                        RenderValuePart(part));
                }

                output.Append("\"");
            }

            if (element.IsEmpty)
            {
                output.Append("/>");
                output.AppendLine();
                return;
            }

            output.Append(">");

            bool hasChildElement =
                element.Children.Count > 0;

            bool hasContent =
                element.Children.Count > 0 ||
                element.Values.Count > 0;

            if (hasChildElement)
                output.AppendLine();

            foreach (ValuePart part in
                     element.Values)
            {
                output.Append(
                    RenderValuePart(part));
            }

            foreach (Element child in
                     element.Children)
            {
                RenderElement(
                    child,
                    output,
                    depth + 1);
            }

            if (hasChildElement)
                output.Append(indent);

            output.Append("</");
            output.Append(
                EscapeXml(element.Name));
            output.Append(">");

            if (depth > 0 ||
                hasContent)
                output.AppendLine();
        }

        private string RenderValuePart(
            ValuePart part)
        {
            if (!part.IsSubstitution)
            {
                return EscapeXml(
                    part.LiteralText ?? "");
            }

            if (part.SubstitutionId >=
                Values.Count)
            {
                return "";
            }

            ValueSpec value =
                Values[part.SubstitutionId];

            if (part.Optional &&
                value.Type == 0x00)
            {
                return "";
            }

            return EscapeXml(
                DecodeValue(value));
        }

        private bool IsNullValue(
            ushort id)
        {
            if (id >= Values.Count)
                return true;

            return Values[id].Type == 0x00;
        }

        private string DecodeValue(
            ValueSpec value)
        {
            byte[] data =
                GetValueBytes(value);

            switch (value.Type)
            {
                case 0x00:
                    return "";

                case 0x01:
                    return Encoding.Unicode.GetString(
                        data).TrimEnd('\0');

                case 0x02:
                    return Encoding.Default.GetString(
                        data).TrimEnd('\0');

                case 0x03:
                    return data.Length >= 1
                        ? ((sbyte)data[0]).ToString(
                            CultureInfo.InvariantCulture)
                        : "";

                case 0x04:
                    return data.Length >= 1
                        ? data[0].ToString(
                            CultureInfo.InvariantCulture)
                        : "";

                case 0x05:
                    return data.Length >= 2
                        ? BitConverter.ToInt16(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x06:
                    return data.Length >= 2
                        ? BitConverter.ToUInt16(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x07:
                    return data.Length >= 4
                        ? BitConverter.ToInt32(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x08:
                    return data.Length >= 4
                        ? BitConverter.ToUInt32(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x09:
                    return data.Length >= 8
                        ? BitConverter.ToInt64(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x0A:
                    return data.Length >= 8
                        ? BitConverter.ToUInt64(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x0B:
                    return data.Length >= 4
                        ? BitConverter.ToSingle(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x0C:
                    return data.Length >= 8
                        ? BitConverter.ToDouble(
                            data, 0).ToString(
                                CultureInfo.InvariantCulture)
                        : "";

                case 0x0D:
                    return data.Length > 0 &&
                           data[0] != 0
                        ? "true"
                        : "false";

                case 0x0E:
                    return BytesToHex(data);

                case 0x0F:
                    return FormatGuid(data);

                case 0x10:
                    return BytesToHex(data);

                case 0x11:
                    if (data.Length >= 8)
                    {
                        try
                        {
                            DateTime ft =
                                DateTime.FromFileTimeUtc(
                                    BitConverter.ToInt64(
                                        data, 0));

                            return ft.ToString(
                                "yyyy-MM-ddTHH:mm:ss.fffffffZ",
                                CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            return "";
                        }
                    }
                    return "";

                case 0x12:
                    return FormatSystemTime(data);

                case 0x13:
                    return FormatSid(data);

                case 0x14:
                    return data.Length >= 4
                        ? "0x" +
                          BitConverter.ToUInt32(
                              data, 0).ToString("X8")
                        : "";

                case 0x15:
                    return data.Length >= 8
                        ? "0x" +
                          BitConverter.ToUInt64(
                              data, 0).ToString("X16")
                        : "";

                case 0x21:
                    /*
                     * BinXmlType contains a complete nested
                     * BinXML fragment/template instance.
                     */
                    try
                    {
                        BinXmlParser nested =
                            new BinXmlParser(
                                data,
                                FileData,
                                ChunkOffset);

                        string xml =
                            nested.ParseDocument();

                        return xml ?? "";
                    }
                    catch
                    {
                        return "";
                    }

                case 0x81:
                    return DecodeStringArray(data);

                case 0x82:
                    return DecodeAnsiStringArray(data);

                case 0x87:
                    return DecodeUInt32Array(data);

                case 0x88:
                    return DecodeUInt32Array(data);

                case 0x8A:
                    return DecodeUInt64Array(data);

                default:
                    return BytesToHex(data);
            }
        }

        private byte[] GetValueBytes(
            ValueSpec value)
        {
            if (value.Size == 0)
                return new byte[0];

            byte[] result =
                new byte[value.Size];

            Buffer.BlockCopy(
                Bin,
                value.DataOffset,
                result,
                0,
                value.Size);

            return result;
        }

        private string DecodeStringArray(
            byte[] data)
        {
            List<string> values =
                new List<string>();

            int p = 0;

            while (p + 1 < data.Length)
            {
                int start = p;

                while (p + 1 < data.Length)
                {
                    if (data[p] == 0x00 &&
                        data[p + 1] == 0x00)
                    {
                        break;
                    }

                    p += 2;
                }

                int length =
                    p - start;

                if (length > 0)
                {
                    values.Add(
                        Encoding.Unicode.GetString(
                            data,
                            start,
                            length));
                }

                if (p + 1 < data.Length)
                    p += 2;
                else
                    break;
            }

            return String.Join(
                "; ",
                values.ToArray());
        }

        private string DecodeAnsiStringArray(
            byte[] data)
        {
            List<string> values =
                new List<string>();

            int start = 0;

            for (int i = 0;
                 i <= data.Length;
                 i++)
            {
                if (i == data.Length ||
                    data[i] == 0)
                {
                    if (i > start)
                    {
                        values.Add(
                            Encoding.Default.GetString(
                                data,
                                start,
                                i - start));
                    }

                    start = i + 1;
                }
            }

            return String.Join(
                "; ",
                values.ToArray());
        }

        private string DecodeUInt32Array(
            byte[] data)
        {
            List<string> values =
                new List<string>();

            for (int i = 0;
                 i + 4 <= data.Length;
                 i += 4)
            {
                values.Add(
                    BitConverter.ToUInt32(
                        data,
                        i).ToString(
                            CultureInfo.InvariantCulture));
            }

            return String.Join(
                ", ",
                values.ToArray());
        }

        private string DecodeUInt64Array(
            byte[] data)
        {
            List<string> values =
                new List<string>();

            for (int i = 0;
                 i + 8 <= data.Length;
                 i += 8)
            {
                values.Add(
                    BitConverter.ToUInt64(
                        data,
                        i).ToString(
                            CultureInfo.InvariantCulture));
            }

            return String.Join(
                ", ",
                values.ToArray());
        }

        private string FormatGuid(
            byte[] data)
        {
            if (data.Length != 16)
                return BytesToHex(data);

            byte[] g =
                new byte[16];

            Buffer.BlockCopy(
                data,
                0,
                g,
                0,
                16);

            Guid guid =
                new Guid(g);

            return guid.ToString();
        }

        private string FormatSystemTime(
            byte[] data)
        {
            if (data.Length < 16)
                return BytesToHex(data);

            try
            {
                ushort year =
                    BitConverter.ToUInt16(data, 0);

                ushort month =
                    BitConverter.ToUInt16(data, 2);

                ushort day =
                    BitConverter.ToUInt16(data, 6);

                ushort hour =
                    BitConverter.ToUInt16(data, 8);

                ushort minute =
                    BitConverter.ToUInt16(data, 10);

                ushort second =
                    BitConverter.ToUInt16(data, 12);

                ushort ms =
                    BitConverter.ToUInt16(data, 14);

                DateTime dt =
                    new DateTime(
                        year,
                        month,
                        day,
                        hour,
                        minute,
                        second,
                        ms,
                        DateTimeKind.Utc);

                return dt.ToString(
                    "yyyy-MM-ddTHH:mm:ss.fffZ",
                    CultureInfo.InvariantCulture);
            }
            catch
            {
                return BytesToHex(data);
            }
        }

        private string FormatSid(
            byte[] data)
        {
            if (data.Length < 8)
                return BytesToHex(data);

            try
            {
                int revision =
                    data[0];

                int subAuthorityCount =
                    data[1];

                ulong identifierAuthority = 0;

                for (int i = 2; i < 8; i++)
                {
                    identifierAuthority =
                        (identifierAuthority << 8) |
                        data[i];
                }

                StringBuilder sid =
                    new StringBuilder();

                sid.Append("S-");
                sid.Append(revision);
                sid.Append("-");
                sid.Append(identifierAuthority);

                int p = 8;

                for (int i = 0;
                     i < subAuthorityCount;
                     i++)
                {
                    if (p + 4 > data.Length)
                        break;

                    uint sub =
                        BitConverter.ToUInt32(
                            data,
                            p);

                    sid.Append("-");
                    sid.Append(sub);

                    p += 4;
                }

                return sid.ToString();
            }
            catch
            {
                return BytesToHex(data);
            }
        }

        private string BytesToHex(
            byte[] data)
        {
            StringBuilder sb =
                new StringBuilder();

            for (int i = 0;
                 i < data.Length;
                 i++)
            {
                if (i > 0)
                    sb.Append(" ");

                sb.Append(
                    data[i].ToString("X2"));
            }

            return sb.ToString();
        }

        private string EscapeXml(
            string value)
        {
            if (String.IsNullOrEmpty(value))
                return "";

            return value
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("\"", "&quot;");
        }
    }

    class TemplateDefinition
    {
        public int TemplateFragmentOffset;
        public int TemplateEndOffset;
        public int ValueSpecOffset;
    }

    class ValueSpec
    {
        public ushort Size;
        public byte Type;
        public int DataOffset;
    }

    class Element
    {
        public string Name;
        public ushort Dependency;
        public bool IsEmpty;

        public List<AttributeNode> Attributes =
            new List<AttributeNode>();

        public List<Element> Children =
            new List<Element>();

        public List<ValuePart> Values =
            new List<ValuePart>();
    }

    class AttributeNode
    {
        public string Name;

        public List<ValuePart> Values =
            new List<ValuePart>();
    }

    class ValuePart
    {
        public bool IsSubstitution;
        public bool Optional;
        public ushort SubstitutionId;
        public byte ExpectedType;
        public string LiteralText;
    }
}
