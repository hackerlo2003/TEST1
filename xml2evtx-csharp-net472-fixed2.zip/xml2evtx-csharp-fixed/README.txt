xml2evtx C# / .NET Framework 4.7.2 - fixed

This version follows xml2evtx.py more closely. In particular, CreateChunk()
now performs the two post-processing steps present in the Python implementation:
- patches chunk offset 0x2c with the last event record signature offset
- recalculates/writes the chunk checksum at 0x7c over [0:120] + [128:512]

Build:
  csc /target:exe /out:Xml2Evtx.exe Xml2Evtx.cs

Run:
  Xml2Evtx.exe -x file.xml
