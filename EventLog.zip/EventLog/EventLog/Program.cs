﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace EvtxParser
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"C:\Windows\Temp\test.evtx";

            if (!File.Exists(filePath))
            {
                Console.WriteLine("[-] File not found: " + filePath);
                return;
            }

            EvtxFile evtx = new EvtxFile(filePath);
            evtx.Parse();

            Console.WriteLine();
            Console.WriteLine("[+] Done.");
            Console.WriteLine("[+] Chunks : " + evtx.Chunks.Count);
            Console.WriteLine("[+] Records: " + evtx.TotalRecords);
        }
    }

    // ============================================================
    // EVTX FILE
    // ============================================================

    class EvtxFile
    {
        public byte[] Data;
        public List<EvtxChunk> Chunks =
            new List<EvtxChunk>();

        public int TotalRecords
        {
            get
            {
                int count = 0;

                foreach (EvtxChunk chunk in Chunks)
                    count += chunk.Records.Count;

                return count;
            }
        }

        public EvtxFile(string path)
        {
            Data = File.ReadAllBytes(path);
        }

        public void Parse()
        {
            Console.WriteLine("========================================");
            Console.WriteLine("EVTX PARSER");
            Console.WriteLine("========================================");

            Console.WriteLine(
                "[+] File size: " +
                Data.Length +
                " bytes");

            if (!CheckFileHeader())
            {
                Console.WriteLine(
                    "[-] Invalid EVTX file.");

                return;
            }

            Console.WriteLine(
                "[+] EVTX header OK");

            Console.WriteLine();

            /*
             * EVTX File Header:
             * 4096 bytes
             *
             * EVTX Chunk:
             * 65536 bytes
             */

            const int FILE_HEADER_SIZE = 4096;
            const int CHUNK_SIZE = 65536;

            int offset = FILE_HEADER_SIZE;

            int chunkIndex = 0;

            while (offset + CHUNK_SIZE <= Data.Length)
            {
                Console.WriteLine(
                    "----------------------------------------");

                Console.WriteLine(
                    "Chunk #" +
                    chunkIndex);

                Console.WriteLine(
                    "Offset: " +
                    offset);

                EvtxChunk chunk =
                    new EvtxChunk(
                        Data,
                        offset,
                        chunkIndex);

                if (!chunk.Parse())
                {
                    Console.WriteLine(
                        "[-] Invalid chunk.");

                    break;
                }

                Chunks.Add(chunk);

                offset += CHUNK_SIZE;

                chunkIndex++;
            }
        }

        private bool CheckFileHeader()
        {
            /*
             * EVTX file signature:
             *
             * 45 6C 66 46 69 6C 65
             *
             * "ElfFile"
             */

            if (Data.Length < 7)
                return false;

            byte[] magic =
                Encoding.ASCII.GetBytes(
                    "ElfFile");

            for (int i = 0;
                 i < magic.Length;
                 i++)
            {
                if (Data[i] != magic[i])
                    return false;
            }

            return true;
        }
    }

    // ============================================================
    // CHUNK
    // ============================================================

    class EvtxChunk
    {
        private byte[] Data;

        private int Offset;

        private int Index;

        public List<EvtxRecord> Records =
            new List<EvtxRecord>();

        public EvtxChunk(
            byte[] data,
            int offset,
            int index)
        {
            Data = data;
            Offset = offset;
            Index = index;
        }

        public bool Parse()
        {
            /*
             * Chunk signature:
             *
             * 45 6C 66 43 68 6E 6B
             *
             * "ElfChnk"
             */

            string signature =
                ReadAscii(
                    Offset,
                    7);

            if (signature != "ElfChnk")
            {
                Console.WriteLine(
                    "[-] Chunk signature invalid: " +
                    signature);

                return false;
            }

            Console.WriteLine(
                "[+] Signature : ElfChnk");

            /*
             * Chunk Header
             *
             * +8  = First Record ID
             * +16 = Last Record ID
             * +24 = First Record Offset
             * +28 = Last Record Offset
             */

            ulong firstRecordId =
                ReadUInt64(
                    Offset + 8);

            ulong lastRecordId =
                ReadUInt64(
                    Offset + 16);

            uint firstRecordOffset =
                ReadUInt32(
                    Offset + 24);

            uint lastRecordOffset =
                ReadUInt32(
                    Offset + 28);

            Console.WriteLine(
                "[+] First Record ID : " +
                firstRecordId);

            Console.WriteLine(
                "[+] Last Record ID  : " +
                lastRecordId);

            Console.WriteLine(
                "[+] First Record Offset: " +
                firstRecordOffset);

            Console.WriteLine(
                "[+] Last Record Offset : " +
                lastRecordOffset);

            /*
             * Search inside this chunk.
             *
             * 512 bytes is the normal starting
             * point used by this experimental
             * scanner.
             */

            int searchStart =
                Offset + 512;

            int searchEnd =
                Offset + 65536;

            int recordCount = 0;

            for (int pos = searchStart;
                 pos + 8 <= searchEnd;
                 pos++)
            {
                if (!IsRecordSignature(pos))
                    continue;

                EvtxRecord record =
                    new EvtxRecord(
                        Data,
                        pos,
                        Index,
                        recordCount);

                if (record.Parse())
                {
                    Records.Add(record);

                    recordCount++;

                    /*
                     * Skip to the end of this record.
                     */

                    if (record.RecordSize >= 24)
                    {
                        pos +=
                            (int)record.RecordSize - 1;
                    }
                }
            }

            Console.WriteLine(
                "[+] Records found: " +
                Records.Count);

            return true;
        }

        private bool IsRecordSignature(
            int pos)
        {
            return
                Data[pos] == 0x2A &&
                Data[pos + 1] == 0x2A &&
                Data[pos + 2] == 0x00 &&
                Data[pos + 3] == 0x00;
        }

        private string ReadAscii(
            int pos,
            int length)
        {
            return Encoding.ASCII.GetString(
                Data,
                pos,
                length);
        }

        private uint ReadUInt32(
            int pos)
        {
            return BitConverter.ToUInt32(
                Data,
                pos);
        }

        private ulong ReadUInt64(
            int pos)
        {
            return BitConverter.ToUInt64(
                Data,
                pos);
        }
    }

    // ============================================================
    // EVENT RECORD
    // ============================================================

    class EvtxRecord
    {
        private byte[] Data;

        public int Offset;

        public int ChunkIndex;

        public int Index;

        public uint RecordSize;

        public ulong RecordId;

        public ulong Timestamp;

        public byte[] BinXml;

        public EvtxRecord(
            byte[] data,
            int offset,
            int chunkIndex,
            int index)
        {
            Data = data;

            Offset = offset;

            ChunkIndex = chunkIndex;

            Index = index;
        }

        public bool Parse()
        {
            /*
             * Event Record:
             *
             * Offset + 0
             *   Signature       4 bytes
             *
             * Offset + 4
             *   Record Size     4 bytes
             *
             * Offset + 8
             *   Record ID       8 bytes
             *
             * Offset + 16
             *   Timestamp       8 bytes
             *
             * Offset + 24
             *   BinXML
             */

            if (Offset + 24 >= Data.Length)
                return false;

            if (!IsSignature())
                return false;

            /*
             * RecordSize
             *
             * Offset + 4
             */

            RecordSize =
                BitConverter.ToUInt32(
                    Data,
                    Offset + 4);

            /*
             * Record ID
             *
             * Offset + 8
             */

            RecordId =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 8);

            /*
             * FILETIME
             *
             * Offset + 16
             */

            Timestamp =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 16);

            /*
             * Basic validation.
             */

            if (RecordSize < 24)
                return false;

            if (RecordSize > 65536)
                return false;

            if (Offset + RecordSize >
                Data.Length)
                return false;

            /*
             * RecordSize is duplicated
             * at the end of the record.
             */

            uint tailSize =
                BitConverter.ToUInt32(
                    Data,
                    Offset +
                    (int)RecordSize -
                    4);

            if (tailSize != RecordSize)
            {
                Console.WriteLine(
                    "[!] Record size footer mismatch " +
                    "at offset " +
                    Offset);
            }

            /*
             * BinXML starts at:
             *
             * Record + 24
             *
             * The last 4 bytes are
             * the duplicated RecordSize.
             */

            int binXmlSize =
                (int)RecordSize -
                24 -
                4;

            if (binXmlSize <= 0)
                return false;

            BinXml =
                new byte[binXmlSize];

            Buffer.BlockCopy(
                Data,
                Offset + 24,
                BinXml,
                0,
                binXmlSize);

            PrintRecord();

            return true;
        }

        private bool IsSignature()
        {
            return
                Data[Offset] == 0x2A &&
                Data[Offset + 1] == 0x2A &&
                Data[Offset + 2] == 0x00 &&
                Data[Offset + 3] == 0x00;
        }

        private void PrintRecord()
        {
            Console.WriteLine();

            Console.WriteLine(
                "  Record #" +
                Index);

            Console.WriteLine(
                "  Offset   : " +
                Offset);

            Console.WriteLine(
                "  Size     : " +
                RecordSize);

            Console.WriteLine(
                "  Record ID: " +
                RecordId);

            Console.WriteLine(
                "  Timestamp raw: " +
                Timestamp);

            try
            {
                DateTime time =
                    DateTime.FromFileTimeUtc(
                        (long)Timestamp);

                Console.WriteLine(
                    "  Timestamp: " +
                    time.ToString(
                        "yyyy-MM-dd HH:mm:ss.fffffff"));
            }
            catch
            {
                Console.WriteLine(
                    "  Timestamp: invalid FILETIME");
            }

            Console.WriteLine(
                "  BinXML size: " +
                BinXml.Length);

            Console.WriteLine(
                "  BinXML:");

            PrintHex(
                BinXml,
                128);

            Console.WriteLine(
                "  UTF-16 strings:");

            ExtractUnicodeStrings(
                BinXml);
        }

        private void ExtractUnicodeStrings(
            byte[] data)
        {
            StringBuilder current =
                new StringBuilder();

            for (int i = 0;
                 i + 1 < data.Length;
                 i += 2)
            {
                ushort value =
                    BitConverter.ToUInt16(
                        data,
                        i);

                if (value >= 32 &&
                    value <= 126)
                {
                    current.Append(
                        (char)value);
                }
                else
                {
                    if (current.Length >= 3)
                    {
                        Console.WriteLine(
                            "    \"" +
                            current.ToString() +
                            "\"");
                    }

                    current.Clear();
                }
            }

            if (current.Length >= 3)
            {
                Console.WriteLine(
                    "    \"" +
                    current.ToString() +
                    "\"");
            }
        }

        private void PrintHex(
            byte[] data,
            int max)
        {
            int length =
                Math.Min(
                    data.Length,
                    max);

            for (int i = 0;
                 i < length;
                 i += 16)
            {
                Console.Write(
                    "    {0}: ",
                    i);

                int lineLength =
                    Math.Min(
                        16,
                        length - i);

                for (int j = 0;
                     j < lineLength;
                     j++)
                {
                    Console.Write(
                        "{0:X2} ",
                        data[i + j]);
                }

                Console.WriteLine();
            }

            if (data.Length > max)
            {
                Console.WriteLine(
                    "    ... " +
                    (data.Length - max) +
                    " bytes omitted");
            }
        }
    }
}