﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Xml2Evtx
{
    class Program
    {
        // ===================== Constants =====================
        static readonly ulong EVTX_HEADER_SIGNATURE = 0x456c6646696c6500UL;       // "ElfFile\0"
        static readonly ulong EVTX_CHUNK_HEADER_SIGNATURE = 0x456C6643686E6B00UL; // "ElfChnk\0"
        static readonly uint EVTX_EVENT_RECORD_HEADER_SIGNATURE = 0x2a2a0000U;
        static readonly uint FLAGMENT_HEADER = 0x0f010100U;

        const ushort EVTX_MAJOR_VERSION = 0x0003;
        const ushort EVTX_MINOR_VERSION = 0x0002;

        const int MAX_CHUNK_SIZE = 0x10000;
        const int HEADER_SIZE = 128;
        const int HEADER_BLOCK_SIZE = 4096;
        const ulong START_EVENT_RECORD_ID = 1;

        // ===================== Token / Value Types =====================
        static class TOKEN_TYPE
        {
            public const byte BinXmlTokenEOF = 0x00;
            public const byte BinXmlTokenOpenStartElementTag_noAttribute = 0x01;
            public const byte BinXmlTokenCloseStartElementTag = 0x02;
            public const byte BinXmlTokenCloseEmptyElementTag = 0x03;
            public const byte BinXmlTokenEndElementTag = 0x04;
            public const byte BinXmlTokenValue = 0x05;
            public const byte BinXmlTokenAttribute = 0x06;
            public const byte BinXmlTokenOpenStartElementTag_Attribute = 0x41;
            public const byte BinXmlTokenAttribute_Next = 0x46;
        }

        static class VALUE_TYPE
        {
            public const byte StringType = 0x01;
        }

        // ===================== Global =====================
        static string XmlFile = null;

        static void Main(string[] args)
        {
            ParseArgs(args);

            if (string.IsNullOrEmpty(XmlFile))
            {
                Console.WriteLine("Usage: Xml2Evtx.exe -x <xmlfile>");
                return;
            }

            if (!File.Exists(XmlFile))
            {
                Console.WriteLine("File not found: " + XmlFile);
                return;
            }

            Console.WriteLine("start create EVTX.");

            var result = ProcessXmlFile(XmlFile);
            int totalEventCount = result.Item1;
            int totalChunkCount = result.Item2;
            byte[] evtxChunk = result.Item3;

            Console.WriteLine($"total event log is {totalEventCount}.");

            byte[] evtxData = CreateEvtx(evtxChunk, totalEventCount, totalChunkCount);

            string evtxFileName = XmlFile + ".evtx";
            File.WriteAllBytes(evtxFileName, evtxData);

            Console.WriteLine($"created {evtxFileName}.");
        }

        static void ParseArgs(string[] args)
        {
            for (int i = 0; i < args.Length; i++)
            {
                string a = args[i].ToLowerInvariant();
                if ((a == "-x" || a == "--xml") && i + 1 < args.Length)
                {
                    XmlFile = args[++i];
                }
            }
        }

        // ===================== Helpers =====================

        static byte[] ToWordPack(string str)
        {
            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms, Encoding.Unicode))
            {
                foreach (char c in str)
                {
                    bw.Write((byte)c);
                    bw.Write((byte)0);
                }
            }
            return ms.ToArray();
        }

        static ushort CalcNameHash(string name)
        {
            uint hashVal = 0;
            for (int i = 0; i < name.Length; i++)
            {
                hashVal = hashVal * 65599 + (uint)name[i];
            }
            return (ushort)(hashVal & 0xFFFF);
        }

        static ulong GetNtTime(DateTime dt)
        {
            return (ulong)dt.ToFileTimeUtc();
        }

        // CRC32 (tương đương zlib.crc32)
        static uint Crc32(byte[] data, int offset, int length)
        {
            uint crc = 0xFFFFFFFF;
            for (int i = offset; i < offset + length; i++)
            {
                crc ^= data[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 1) != 0)
                        crc = (crc >> 1) ^ 0xEDB88320;
                    else
                        crc >>= 1;
                }
            }
            return ~crc;
        }

        static uint Crc32(byte[] data)
        {
            return Crc32(data, 0, data.Length);
        }

        static void WriteUInt64BE(BinaryWriter bw, ulong value)
        {
            byte[] b = BitConverter.GetBytes(value);
            if (BitConverter.IsLittleEndian) Array.Reverse(b);
            bw.Write(b);
        }

        static void WriteUInt32BE(BinaryWriter bw, uint value)
        {
            byte[] b = BitConverter.GetBytes(value);
            if (BitConverter.IsLittleEndian) Array.Reverse(b);
            bw.Write(b);
        }

        // ===================== XML processing =====================

        static IEnumerable<XElement> XmlRecords(string filename)
        {
            string xdata = File.ReadAllText(filename, Encoding.UTF8);

            xdata = xdata.Replace("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>", "")
                         .Replace("</Events>", "")
                         .Replace("<Events>", "");

            var parts = Regex.Split(xdata, "<Event xmlns=['\"]http://schemas.microsoft.com/win/2004/08/events/event['\"]>");

            foreach (var part in parts)
            {
                if (part.Trim().StartsWith("<System>"))
                {
                    string fullXml = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?><Event>" + part;
                    XElement node = null;
                    try
                    {
                        node = XElement.Parse(fullXml);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("XML parse error: " + ex.Message);
                        continue;
                    }
                    yield return node;
                }
            }
        }

        // ===================== BinXML building =====================

        static byte[] CreateNameChunk(string nameElement)
        {
            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                bw.Write((uint)0);                          // unknown
                bw.Write(CalcNameHash(nameElement));        // name_hash
                bw.Write((ushort)nameElement.Length);       // number_of_characters
                bw.Write(ToWordPack(nameElement));
                bw.Write((ushort)0);                        // end of BinXML
            }
            return ms.ToArray();
        }

        static byte[] CreateValueChunk(string valueElement)
        {
            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                bw.Write(TOKEN_TYPE.BinXmlTokenValue);
                bw.Write(VALUE_TYPE.StringType);
                bw.Write((ushort)valueElement.Length);
                bw.Write(ToWordPack(valueElement));
            }
            return ms.ToArray();
        }

        static byte[] CreateAttributeChunk(Dictionary<string, string> attribs)
        {
            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                int count = 0;
                foreach (var kv in attribs)
                {
                    byte attributeToken = (count == attribs.Count - 1)
                        ? TOKEN_TYPE.BinXmlTokenAttribute
                        : TOKEN_TYPE.BinXmlTokenAttribute_Next;

                    bw.Write(attributeToken);
                    bw.Write((uint)0x88888888); // placeholder attribute_name_offset

                    bw.Write(CreateNameChunk(kv.Key));
                    bw.Write(CreateValueChunk(kv.Value));
                    count++;
                }
            }

            byte[] attrData = ms.ToArray();
            var result = new MemoryStream();
            using (var bw = new BinaryWriter(result))
            {
                bw.Write((uint)attrData.Length);
                bw.Write(attrData);
            }
            return result.ToArray();
        }

        static byte[] ElementStart(byte[] data, byte tokenStart)
        {
            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                bw.Write(tokenStart);
                bw.Write((uint)(data.Length + 4)); // data_size
                bw.Write((uint)0x99999999);        // placeholder element_name_offset
                bw.Write(data);
            }
            return ms.ToArray();
        }

        static byte[] CreateEventDetails(XElement node1st)
        {
            var eventDetails = new MemoryStream();

            foreach (var node2nd in node1st.Elements())
            {
                byte[] nameChunk = CreateNameChunk(node2nd.Name.LocalName);
                byte[] valueText;
                byte tokenClose;

                if (!string.IsNullOrEmpty(node2nd.Value) && !node2nd.HasElements)
                {
                    tokenClose = TOKEN_TYPE.BinXmlTokenEndElementTag;
                    valueText = new byte[] { TOKEN_TYPE.BinXmlTokenCloseStartElementTag }
                                .Concat(CreateValueChunk(node2nd.Value)).ToArray();
                }
                else
                {
                    tokenClose = TOKEN_TYPE.BinXmlTokenCloseEmptyElementTag;
                    valueText = new byte[0];
                }

                byte[] eventDetailsData;
                byte tokenStart;

                if (node2nd.HasAttributes)
                {
                    tokenStart = TOKEN_TYPE.BinXmlTokenOpenStartElementTag_Attribute;
                    var attribDict = node2nd.Attributes()
                        .ToDictionary(a => a.Name.LocalName, a => a.Value);

                    eventDetailsData = nameChunk
                        .Concat(CreateAttributeChunk(attribDict))
                        .Concat(valueText)
                        .Concat(new byte[] { tokenClose })
                        .ToArray();
                }
                else
                {
                    tokenStart = TOKEN_TYPE.BinXmlTokenOpenStartElementTag_noAttribute;
                    eventDetailsData = nameChunk
                        .Concat(valueText)
                        .Concat(new byte[] { tokenClose })
                        .ToArray();
                }

                byte[] started = ElementStart(eventDetailsData, tokenStart);
                eventDetails.Write(started, 0, started.Length);
            }

            return eventDetails.ToArray();
        }

        static byte[] ProcessNodes(XElement node)
        {
            var binxmlChunk = new MemoryStream();

            foreach (var node1st in node.Elements())
            {
                byte[] eventDetails = CreateEventDetails(node1st);

                byte[] binxml1st = CreateNameChunk(node1st.Name.LocalName)
                    .Concat(new byte[] { TOKEN_TYPE.BinXmlTokenCloseStartElementTag })
                    .ToArray();

                byte[] started = ElementStart(binxml1st.Concat(eventDetails).ToArray(),
                                              TOKEN_TYPE.BinXmlTokenOpenStartElementTag_noAttribute);

                binxmlChunk.Write(started, 0, started.Length);
                binxmlChunk.WriteByte(TOKEN_TYPE.BinXmlTokenEndElementTag);
            }

            return binxmlChunk.ToArray();
        }

        static byte[] ConvertXmlToBinXml(XElement node, int eventNumber)
        {
            byte[] binxmlChunk = ProcessNodes(node);

            byte[] binxmlEvent = CreateNameChunk("Event")
                .Concat(CreateAttributeChunk(new Dictionary<string, string>
                {
                    { "xmlns", "http://schemas.microsoft.com/win/2004/08/events/event" }
                }))
                .Concat(new byte[] { TOKEN_TYPE.BinXmlTokenCloseStartElementTag })
                .ToArray();

            byte[] binxml = ElementStart(binxmlEvent.Concat(binxmlChunk).ToArray(),
                                         TOKEN_TYPE.BinXmlTokenOpenStartElementTag_Attribute)
                .Concat(new byte[] { TOKEN_TYPE.BinXmlTokenEndElementTag })
                .ToArray();

            return CreateEventRecord(binxml.Concat(new byte[] { TOKEN_TYPE.BinXmlTokenEOF }).ToArray(), eventNumber);
        }

        static byte[] CreateEventRecord(byte[] data, int count)
        {
            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                WriteUInt32BE(bw, EVTX_EVENT_RECORD_HEADER_SIGNATURE);
                bw.Write((uint)(data.Length + 0x20));                     // size
                bw.Write(START_EVENT_RECORD_ID + (ulong)count - 1);       // identifier
                bw.Write(GetNtTime(DateTime.UtcNow));                     // written_time

                WriteUInt32BE(bw, FLAGMENT_HEADER);
                bw.Write(data);
                bw.Write((uint)(data.Length + 0x20));                     // size copy
            }
            return ms.ToArray();
        }

        // ===================== Fix offsets =====================

        static byte[] FixBinXmlOffset(byte[] binxml)
        {
            byte[] result = (byte[])binxml.Clone();

            // element_name_offset placeholder 0x99999999
            for (int i = 0; i < result.Length - 3; i++)
            {
                if (result[i] == 0x99 && result[i + 1] == 0x99 && result[i + 2] == 0x99 && result[i + 3] == 0x99)
                {
                    uint offset = (uint)(i + 0x204);
                    byte[] offBytes = BitConverter.GetBytes(offset);
                    Array.Copy(offBytes, 0, result, i, 4);
                }
            }

            // attribute_name_offset placeholder 0x88888888
            for (int i = 0; i < result.Length - 3; i++)
            {
                if (result[i] == 0x88 && result[i + 1] == 0x88 && result[i + 2] == 0x88 && result[i + 3] == 0x88)
                {
                    uint offset = (uint)(i + 0x204);
                    byte[] offBytes = BitConverter.GetBytes(offset);
                    Array.Copy(offBytes, 0, result, i, 4);
                }
            }

            return result;
        }

        // ===================== Chunk / Header =====================

        static byte[] CreateEvtxChunk(byte[] data, int eventCount)
        {
            ulong lastEventRecordNumber = START_EVENT_RECORD_ID + (ulong)eventCount - 1;
            uint freeSpaceOffset = (uint)(data.Length + 0x0200);

            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                WriteUInt64BE(bw, EVTX_CHUNK_HEADER_SIGNATURE);

                bw.Write((ulong)0x01);                              // first_event_record_number
                bw.Write((ulong)eventCount);                        // last_event_record_number
                bw.Write(START_EVENT_RECORD_ID);                    // first_event_record_identifier
                bw.Write(lastEventRecordNumber);                    // last_event_record_identifier
                bw.Write((uint)HEADER_SIZE);                        // header_size
                bw.Write((uint)0);                                  // last_event_record_offset (placeholder)
                bw.Write(freeSpaceOffset);                          // free_space_offset
                bw.Write(Crc32(data));                              // event_records_checksum

                bw.Write(new byte[64]);                             // unknown1
                bw.Write((uint)0x01);                               // unknown2

                // checksum placeholder
                bw.Write((uint)0);

                // Common string offset array
                bw.Write(new byte[12]);
                bw.Write((ushort)0);
                bw.Write(new byte[370]);
            }

            byte[] headerPart = ms.ToArray();

            var finalMs = new MemoryStream();
            finalMs.Write(headerPart, 0, headerPart.Length);
            finalMs.Write(data, 0, data.Length);

            // Pad to MAX_CHUNK_SIZE
            int padLen = MAX_CHUNK_SIZE - (int)finalMs.Length;
            if (padLen > 0)
                finalMs.Write(new byte[padLen], 0, padLen);

            byte[] chunk = finalMs.ToArray();

            // Fix last_event_record_offset
            int lastRecordOffset = -1;
            for (int i = chunk.Length - 4; i >= 0; i--)
            {
                if (chunk[i] == 0x2a && chunk[i + 1] == 0x2a && chunk[i + 2] == 0x00 && chunk[i + 3] == 0x00)
                {
                    lastRecordOffset = i;
                    break;
                }
            }
            if (lastRecordOffset >= 0)
            {
                byte[] off = BitConverter.GetBytes((uint)lastRecordOffset);
                Array.Copy(off, 0, chunk, 0x2c, 4);
            }

            // Fix checksum (CRC of 0-120 + 128-512)
            byte[] forCrc = new byte[120 + (512 - 128)];
            Array.Copy(chunk, 0, forCrc, 0, 120);
            Array.Copy(chunk, 128, forCrc, 120, 512 - 128);
            uint finalChecksum = Crc32(forCrc);
            byte[] csBytes = BitConverter.GetBytes(finalChecksum);
            Array.Copy(csBytes, 0, chunk, 124, 4);

            return chunk;
        }

        static byte[] CreateChunk(byte[] binxml, int totalEventCount, int totalChunkCount)
        {
            byte[] fixedBinxml = FixBinXmlOffset(binxml);
            byte[] chunk = CreateEvtxChunk(fixedBinxml, totalEventCount);

            Console.WriteLine($"finished chunk {totalChunkCount}.");
            return chunk;
        }

        static byte[] CreateEvtx(byte[] data, int eventCount, int chunkCount)
        {
            var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                WriteUInt64BE(bw, EVTX_HEADER_SIGNATURE);

                bw.Write((ulong)0);                                 // first_chunk_number
                bw.Write((ulong)chunkCount);                        // last_chunk_number
                bw.Write(START_EVENT_RECORD_ID + (ulong)eventCount);// next_record_identifier
                bw.Write((uint)HEADER_SIZE);                        // header_size
                bw.Write(EVTX_MINOR_VERSION);
                bw.Write(EVTX_MAJOR_VERSION);
                bw.Write((ushort)HEADER_BLOCK_SIZE);
                bw.Write((ushort)(chunkCount + 1));                 // number_of_chunks

                bw.Write(new byte[76]);                             // unknown1
                bw.Write((uint)0x0001);                             // file_flags

                // checksum placeholder
                bw.Write((uint)0);

                bw.Write(new byte[3968]);                           // unknown2
            }

            byte[] header = ms.ToArray();
            uint checksum = Crc32(header, 0, 120);
            byte[] cs = BitConverter.GetBytes(checksum);
            Array.Copy(cs, 0, header, 120, 4);

            var result = new MemoryStream();
            result.Write(header, 0, header.Length);
            result.Write(data, 0, data.Length);
            return result.ToArray();
        }

        // ===================== Main processing =====================

        static Tuple<int, int, byte[]> ProcessXmlFile(string xmlFile)
        {
            int totalChunkCount = 0;
            int totalEventCount = 0;
            var binxml = new MemoryStream();
            var evtxChunk = new MemoryStream();

            foreach (var node in XmlRecords(xmlFile))
            {
                totalEventCount++;
                byte[] part = ConvertXmlToBinXml(node, totalEventCount);

                if (binxml.Length + part.Length > MAX_CHUNK_SIZE - 0x200)
                {
                    byte[] chunkData = CreateChunk(binxml.ToArray(), totalEventCount, totalChunkCount);
                    evtxChunk.Write(chunkData, 0, chunkData.Length);

                    binxml.SetLength(0);
                    binxml.Write(part, 0, part.Length);
                    totalChunkCount++;
                }
                else
                {
                    binxml.Write(part, 0, part.Length);
                }
            }

            if (binxml.Length > 0)
            {
                byte[] chunkData = CreateChunk(binxml.ToArray(), totalEventCount, totalChunkCount);
                evtxChunk.Write(chunkData, 0, chunkData.Length);
            }

            return Tuple.Create(totalEventCount, totalChunkCount, evtxChunk.ToArray());
        }
    }
}