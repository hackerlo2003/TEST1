﻿//using System;
//using System.IO;
//using System.Text;
//using System.Collections.Generic;

//namespace EvtxParser
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            string path = @"C:\Windows\Temp\test.evtx";

//            if (!File.Exists(path))
//            {
//                Console.WriteLine("[-] File not found: " + path);
//                return;
//            }

//            EvtxFile evtx = new EvtxFile(path);
//            evtx.Parse();

//            Console.WriteLine();
//            Console.WriteLine("[+] Done.");
//            Console.WriteLine("[+] Chunks : " + evtx.Chunks.Count);
//            Console.WriteLine("[+] Records: " + evtx.TotalRecords);
//        }
//    }

//    // ============================================================
//    // EVTX FILE
//    // ============================================================

//    class EvtxFile
//    {
//        public byte[] Data;
//        public List<EvtxChunk> Chunks = new List<EvtxChunk>();

//        public int TotalRecords
//        {
//            get
//            {
//                int count = 0;

//                foreach (EvtxChunk chunk in Chunks)
//                    count += chunk.Records.Count;

//                return count;
//            }
//        }

//        public EvtxFile(string path)
//        {
//            Data = File.ReadAllBytes(path);
//        }

//        public void Parse()
//        {
//            Console.WriteLine("========================================");
//            Console.WriteLine("EVTX PARSER");
//            Console.WriteLine("========================================");

//            Console.WriteLine("[+] File size: " + Data.Length);

//            if (!CheckFileHeader())
//            {
//                Console.WriteLine("[-] Invalid EVTX file.");
//                return;
//            }

//            Console.WriteLine("[+] EVTX header OK");
//            Console.WriteLine();

//            /*
//             * EVTX:
//             *
//             * File Header = 4096 bytes
//             * Chunk      = 65536 bytes
//             */

//            const int FILE_HEADER_SIZE = 0x1000;
//            const int CHUNK_SIZE = 0x10000;

//            int offset = FILE_HEADER_SIZE;
//            int chunkIndex = 0;

//            while (offset + CHUNK_SIZE <= Data.Length)
//            {
//                Console.WriteLine("----------------------------------------");
//                Console.WriteLine("Chunk #" + chunkIndex);
//                Console.WriteLine("Offset: 0x" + offset.ToString("X"));

//                EvtxChunk chunk = new EvtxChunk(
//                    Data,
//                    offset,
//                    chunkIndex
//                );

//                if (!chunk.Parse())
//                {
//                    Console.WriteLine("[-] Invalid chunk.");
//                    break;
//                }

//                Chunks.Add(chunk);

//                offset += CHUNK_SIZE;
//                chunkIndex++;
//            }
//        }

//        private bool CheckFileHeader()
//        {
//            /*
//             * EVTX file header starts with:
//             *
//             * ElfFile
//             */

//            if (Data.Length < 8)
//                return false;

//            byte[] magic = Encoding.ASCII.GetBytes("ElfFile");

//            for (int i = 0; i < magic.Length; i++)
//            {
//                if (Data[i] != magic[i])
//                    return false;
//            }

//            return true;
//        }
//    }

//    // ============================================================
//    // CHUNK
//    // ============================================================

//    class EvtxChunk
//    {
//        private byte[] Data;
//        private int Offset;
//        private int Index;

//        public List<EvtxRecord> Records =
//            new List<EvtxRecord>();

//        public EvtxChunk(
//            byte[] data,
//            int offset,
//            int index)
//        {
//            Data = data;
//            Offset = offset;
//            Index = index;
//        }

//        public bool Parse()
//        {
//            /*
//             * Chunk signature:
//             *
//             * 45 6C 66 43 68 6E 6B
//             *
//             * "ElfChnk"
//             */

//            string signature = ReadAscii(Offset, 7);

//            if (signature != "ElfChnk")
//            {
//                Console.WriteLine(
//                    "[-] Chunk signature invalid: " +
//                    signature);

//                return false;
//            }

//            Console.WriteLine("[+] Signature : ElfChnk");

//            /*
//             * Chunk header fields:
//             *
//             * +0x08  First event record ID
//             * +0x10  Last event record ID
//             * +0x18  First record offset
//             * +0x1C  Last record offset
//             */

//            ulong firstRecordId =
//                ReadUInt64(Offset + 0x08);

//            ulong lastRecordId =
//                ReadUInt64(Offset + 0x10);

//            uint firstRecordOffset =
//                ReadUInt32(Offset + 0x18);

//            uint lastRecordOffset =
//                ReadUInt32(Offset + 0x1C);

//            Console.WriteLine(
//                "[+] First Record ID : " +
//                firstRecordId);

//            Console.WriteLine(
//                "[+] Last Record ID  : " +
//                lastRecordId);

//            Console.WriteLine(
//                "[+] First Record Offset: 0x" +
//                firstRecordOffset.ToString("X"));

//            Console.WriteLine(
//                "[+] Last Record Offset : 0x" +
//                lastRecordOffset.ToString("X"));

//            /*
//             * Record data normally starts at:
//             *
//             * chunk + firstRecordOffset
//             *
//             * We additionally scan for 2A 2A 00 00
//             * inside the valid chunk region.
//             */

//            int searchStart = Offset + 0x200;
//            int searchEnd = Offset + 0x10000;

//            int recordCount = 0;

//            for (int pos = searchStart;
//                 pos + 8 <= searchEnd;
//                 pos++)
//            {
//                if (!IsRecordSignature(pos))
//                    continue;

//                EvtxRecord record =
//                    new EvtxRecord(
//                        Data,
//                        pos,
//                        Index,
//                        recordCount);

//                if (record.Parse())
//                {
//                    Records.Add(record);
//                    recordCount++;

//                    /*
//                     * Jump directly to the next record.
//                     *
//                     * This avoids scanning every byte of
//                     * the current record.
//                     */

//                    if (record.RecordSize >= 0x18)
//                    {
//                        pos +=
//                            (int)record.RecordSize - 1;
//                    }
//                }
//            }

//            Console.WriteLine(
//                "[+] Records found: " +
//                Records.Count);

//            return true;
//        }

//        private bool IsRecordSignature(int pos)
//        {
//            return
//                Data[pos + 0] == 0x2A &&
//                Data[pos + 1] == 0x2A &&
//                Data[pos + 2] == 0x00 &&
//                Data[pos + 3] == 0x00;
//        }

//        private string ReadAscii(int pos, int length)
//        {
//            return Encoding.ASCII.GetString(
//                Data,
//                pos,
//                length);
//        }

//        private uint ReadUInt32(int pos)
//        {
//            return BitConverter.ToUInt32(
//                Data,
//                pos);
//        }

//        private ulong ReadUInt64(int pos)
//        {
//            return BitConverter.ToUInt64(
//                Data,
//                pos);
//        }
//    }

//    // ============================================================
//    // EVENT RECORD
//    // ============================================================

//    class EvtxRecord
//    {
//        private byte[] Data;

//        public int Offset;
//        public int ChunkIndex;
//        public int Index;

//        public uint RecordSize;
//        public ulong RecordId;
//        public ulong Timestamp;

//        public byte[] BinXml;

//        public EvtxRecord(
//            byte[] data,
//            int offset,
//            int chunkIndex,
//            int index)
//        {
//            Data = data;
//            Offset = offset;
//            ChunkIndex = chunkIndex;
//            Index = index;
//        }

//        public bool Parse()
//        {
//            /*
//             * Event Record:
//             *
//             * +0x00 Signature      4 bytes
//             * +0x04 Record Size    4 bytes
//             * +0x08 Record ID      8 bytes
//             * +0x10 Timestamp      8 bytes
//             * +0x18 BinXML
//             *
//             * Record size is also stored at the end.
//             */

//            if (Offset + 0x18 >= Data.Length)
//                return false;

//            if (!IsSignature())
//                return false;

//            RecordSize =
//                BitConverter.ToUInt32(
//                    Data,
//                    Offset + 0x04);

//            RecordId =
//                BitConverter.ToUInt64(
//                    Data,
//                    Offset + 0x08);

//            Timestamp =
//                BitConverter.ToUInt64(
//                    Data,
//                    Offset + 0x10);

//            /*
//             * Basic sanity checks.
//             */

//            if (RecordSize < 0x18)
//                return false;

//            if (RecordSize > 0x10000)
//                return false;

//            if (Offset + RecordSize > Data.Length)
//                return false;

//            /*
//             * Last 4 bytes should contain RecordSize.
//             */

//            uint tailSize =
//                BitConverter.ToUInt32(
//                    Data,
//                    Offset + (int)RecordSize - 4);

//            if (tailSize != RecordSize)
//            {
//                Console.WriteLine(
//                    "[!] Record size footer mismatch " +
//                    "at 0x" +
//                    Offset.ToString("X"));
//            }

//            /*
//             * BinXML starts at +0x18.
//             */

//            int binXmlSize =
//                (int)RecordSize - 0x18 - 4;

//            if (binXmlSize <= 0)
//                return false;

//            BinXml = new byte[binXmlSize];

//            Buffer.BlockCopy(
//                Data,
//                Offset + 0x18,
//                BinXml,
//                0,
//                binXmlSize);

//            PrintRecord();

//            return true;
//        }

//        private bool IsSignature()
//        {
//            return
//                Data[Offset + 0] == 0x2A &&
//                Data[Offset + 1] == 0x2A &&
//                Data[Offset + 2] == 0x00 &&
//                Data[Offset + 3] == 0x00;
//        }

//        private void PrintRecord()
//        {
//            Console.WriteLine();
//            Console.WriteLine(
//                "  Record #" + Index);

//            Console.WriteLine(
//                "  Offset   : 0x" +
//                Offset.ToString("X8"));

//            Console.WriteLine(
//                "  Size     : 0x" +
//                RecordSize.ToString("X"));

//            Console.WriteLine(
//                "  Record ID: " +
//                RecordId);

//            Console.WriteLine(
//                "  Timestamp raw: 0x" +
//                Timestamp.ToString("X16"));

//            Console.WriteLine(
//                "  BinXML size: " +
//                BinXml.Length);

//            /*
//             * Print the first bytes of BinXML.
//             */

//            Console.WriteLine("  BinXML:");

//            PrintHex(BinXml, 128);

//            /*
//             * Search for UTF-16LE strings.
//             */

//            Console.WriteLine(
//                "  UTF-16 strings:");

//            ExtractUnicodeStrings(BinXml);
//        }

//        private void ExtractUnicodeStrings(
//            byte[] data)
//        {
//            StringBuilder current =
//                new StringBuilder();

//            for (int i = 0; i + 1 < data.Length; i += 2)
//            {
//                ushort value =
//                    BitConverter.ToUInt16(
//                        data,
//                        i);

//                /*
//                 * Printable UTF-16LE character.
//                 */

//                if (value >= 0x20 &&
//                    value <= 0x7E)
//                {
//                    current.Append((char)value);
//                }
//                else
//                {
//                    if (current.Length >= 3)
//                    {
//                        Console.WriteLine(
//                            "    \"" +
//                            current.ToString() +
//                            "\"");
//                    }

//                    current.Clear();
//                }
//            }

//            if (current.Length >= 3)
//            {
//                Console.WriteLine(
//                    "    \"" +
//                    current.ToString() +
//                    "\"");
//            }
//        }

//        private void PrintHex(
//            byte[] data,
//            int max)
//        {
//            int length =
//                Math.Min(data.Length, max);

//            for (int i = 0; i < length; i += 16)
//            {
//                Console.Write(
//                    "    {0:X4}: ",
//                    i);

//                int lineLength =
//                    Math.Min(16, length - i);

//                for (int j = 0;
//                     j < lineLength;
//                     j++)
//                {
//                    Console.Write(
//                        "{0:X2} ",
//                        data[i + j]);
//                }

//                Console.WriteLine();
//            }

//            if (data.Length > max)
//            {
//                Console.WriteLine(
//                    "    ... " +
//                    (data.Length - max) +
//                    " bytes omitted");
//            }
//        }
//    }
//}