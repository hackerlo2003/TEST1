using System;
using System.IO;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        string path = args.Length > 0
            ? args[0]
            : @"C:\Windows\System32\winevt\Logs\Security.evtx";

        if (!File.Exists(path))
        {
            Console.WriteLine("[-] File not found: " + path);
            return;
        }

        byte[] data = File.ReadAllBytes(path);

        Console.WriteLine("[+] File size: " + data.Length + " bytes");

        const int fileHeaderSize = 4096;
        const int chunkSize = 65536;

        if (data.Length < fileHeaderSize + chunkSize)
        {
            Console.WriteLine("[-] File is too small.");
            return;
        }

        if (Encoding.ASCII.GetString(data, 0, 7) != "ElfFile")
        {
            Console.WriteLine("[-] Invalid EVTX file.");
            return;
        }

        // Chỉ đọc Record đầu tiên của Chunk đầu tiên.
        int chunkOffset = fileHeaderSize;
        int recordOffset = FindFirstRecord(data, chunkOffset, chunkOffset + chunkSize);

        if (recordOffset < 0)
        {
            Console.WriteLine("[-] Record not found.");
            return;
        }

        uint recordSize = BitConverter.ToUInt32(data, recordOffset + 4);
        ulong recordId = BitConverter.ToUInt64(data, recordOffset + 8);
        ulong timestamp = BitConverter.ToUInt64(data, recordOffset + 16);

        int binXmlSize = (int)recordSize - 24 - 4;

        if (recordSize < 28 ||
            recordOffset + recordSize > data.Length ||
            binXmlSize <= 0)
        {
            Console.WriteLine("[-] Invalid record.");
            return;
        }

        byte[] binXml = new byte[binXmlSize];

        Buffer.BlockCopy(
            data,
            recordOffset + 24,
            binXml,
            0,
            binXmlSize);

        Console.WriteLine();
        Console.WriteLine("========================================");
        Console.WriteLine("RECORD");
        Console.WriteLine("========================================");

        Console.WriteLine("Record Size : " + recordSize + " bytes");
        Console.WriteLine("Record ID   : " + recordId);
        Console.WriteLine("BinXML Size : " + binXmlSize + " bytes");

        try
        {
            DateTime time =
                DateTime.FromFileTimeUtc((long)timestamp);

            Console.WriteLine(
                "Time        : " +
                time.ToString("yyyy-MM-dd HH:mm:ss.fffffff") +
                " UTC");
        }
        catch
        {
            Console.WriteLine("Time        : invalid");
        }

        Console.WriteLine();
        Console.WriteLine("========================================");
        Console.WriteLine("BINXML TEXT");
        Console.WriteLine("========================================");

        ParseBinXmlText(binXml);
    }

    static int FindFirstRecord(
        byte[] data,
        int start,
        int end)
    {
        for (int i = start; i + 4 <= end; i++)
        {
            if (data[i] == 0x2A &&
                data[i + 1] == 0x2A &&
                data[i + 2] == 0x00 &&
                data[i + 3] == 0x00)
            {
                return i;
            }
        }

        return -1;
    }

    static void ParseBinXmlText(byte[] binXml)
    {
        StringBuilder current = new StringBuilder();

        for (int i = 0; i + 1 < binXml.Length; i += 2)
        {
            ushort value =
                BitConverter.ToUInt16(binXml, i);

            if (value >= 32 && value <= 126)
            {
                current.Append((char)value);
            }
            else
            {
                PrintText(current);
                current.Clear();
            }
        }

        PrintText(current);
    }

    static void PrintText(StringBuilder text)
    {
        if (text.Length >= 3)
        {
            Console.WriteLine(text.ToString());
        }
    }
}
