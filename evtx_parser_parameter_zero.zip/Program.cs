using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace EvtxParser
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = args.Length > 0
                ? args[0]
                : @"C:\Windows\System32\winevt\Logs\Security.evtx";

            Console.WriteLine("Is64BitProcess: " + Environment.Is64BitProcess);
            Console.WriteLine("Is64BitOperatingSystem: " +
                              Environment.Is64BitOperatingSystem);
            Console.WriteLine();

            if (!File.Exists(filePath))
            {
                Console.WriteLine("[-] File not found: " + filePath);
                return;
            }

            try
            {
                EvtxFile evtx = new EvtxFile(filePath);

                evtx.Parse();

                Console.WriteLine();
                Console.WriteLine("========================================");
                Console.WriteLine("[+] PARSE SIZE VALIDATION");
                Console.WriteLine("========================================");

                evtx.ValidateAllSizes();

                Console.WriteLine();
                Console.WriteLine("[+] Chunks : " + evtx.Chunks.Count);
                Console.WriteLine("[+] Records: " + evtx.TotalRecords);

                string backupPath = filePath + ".bak";

                Console.WriteLine();
                Console.WriteLine("[+] Creating backup:");
                Console.WriteLine("    " + backupPath);

                File.Copy(filePath, backupPath, true);

                int originalFileSize = evtx.OriginalFileSize;

                Console.WriteLine();
                Console.WriteLine("[+] Writing modified EVTX...");

                File.WriteAllBytes(filePath, evtx.Data);

                FileInfo fileInfo = new FileInfo(filePath);
                long finalFileSize = fileInfo.Length;

                Console.WriteLine();
                Console.WriteLine("========================================");
                Console.WriteLine("[+] FILE SIZE CHECK");
                Console.WriteLine("========================================");

                Console.WriteLine(
                    "[+] Original file size : " +
                    originalFileSize +
                    " bytes");

                Console.WriteLine(
                    "[+] Data[] size        : " +
                    evtx.Data.Length +
                    " bytes");

                Console.WriteLine(
                    "[+] Written file size  : " +
                    finalFileSize +
                    " bytes");

                if (originalFileSize == evtx.Data.Length)
                {
                    Console.WriteLine(
                        "[+] In-memory file size: OK");
                }
                else
                {
                    Console.WriteLine(
                        "[-] In-memory file size: FAILED");
                }

                if (finalFileSize == originalFileSize)
                {
                    Console.WriteLine(
                        "[+] Disk file size: OK");
                }
                else
                {
                    Console.WriteLine(
                        "[-] Disk file size: FAILED");

                    Console.WriteLine(
                        "[-] Difference: " +
                        (finalFileSize - originalFileSize) +
                        " bytes");
                }

                /*
                 * Read the written file again.
                 */

                byte[] verifyData =
                    File.ReadAllBytes(filePath);

                Console.WriteLine();
                Console.WriteLine("========================================");
                Console.WriteLine("[+] READ-BACK SIZE CHECK");
                Console.WriteLine("========================================");

                Console.WriteLine(
                    "[+] Read-back size: " +
                    verifyData.Length +
                    " bytes");

                if (verifyData.Length ==
                    originalFileSize)
                {
                    Console.WriteLine(
                        "[+] Read-back file size: OK");
                }
                else
                {
                    Console.WriteLine(
                        "[-] Read-back file size: FAILED");
                }

                /*
                 * Parse the written bytes again.
                 * This checks record/chunk sizes after the write.
                 */

                Console.WriteLine();
                Console.WriteLine("========================================");
                Console.WriteLine("[+] POST-WRITE STRUCTURAL SIZE CHECK");
                Console.WriteLine("========================================");

                EvtxFile verifyEvtx =
                    new EvtxFile(verifyData);

                verifyEvtx.Parse();

                bool verifyOk =
                    verifyEvtx.ValidateAllSizes();

                Console.WriteLine();

                if (verifyOk)
                {
                    Console.WriteLine(
                        "[+] POST-WRITE SIZE VALIDATION: OK");
                }
                else
                {
                    Console.WriteLine(
                        "[-] POST-WRITE SIZE VALIDATION: FAILED");
                }

                Console.WriteLine();
                Console.WriteLine("[+] Backup: " + backupPath);
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine(
                    "[-] Access denied. Run as Administrator.");
            }
            catch (IOException ex)
            {
                Console.WriteLine(
                    "[-] File is probably locked or in use.");

                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[-] Error:");
                Console.WriteLine(ex);
            }
        }
    }


    // ============================================================
    // EVTX FILE
    // ============================================================

    class EvtxFile
    {
        public byte[] Data;

        public int OriginalFileSize;

        public List<EvtxChunk> Chunks =
            new List<EvtxChunk>();


        public int TotalRecords
        {
            get
            {
                int count = 0;

                foreach (EvtxChunk chunk in Chunks)
                    count += chunk.Records.Count;

                return count;
            }
        }


        public EvtxFile(string path)
        {
            Data =
                File.ReadAllBytes(path);

            OriginalFileSize =
                Data.Length;

            Console.WriteLine(
                "[+] Original file size: " +
                OriginalFileSize +
                " bytes");
        }


        public EvtxFile(byte[] data)
        {
            Data = data;

            OriginalFileSize =
                data.Length;
        }


        public void Parse()
        {
            if (Data == null ||
                Data.Length == 0)
            {
                Console.WriteLine(
                    "[-] Empty file.");

                return;
            }


            if (!CheckFileHeader())
            {
                Console.WriteLine(
                    "[-] Invalid EVTX file.");

                return;
            }


            Console.WriteLine(
                "[+] EVTX header OK");


            const int FILE_HEADER_SIZE = 4096;

            const int CHUNK_SIZE = 65536;


            /*
             * File size must contain:
             *
             * 4096-byte file header
             *
             * plus complete 65536-byte chunks.
             */

            int payloadSize =
                Data.Length -
                FILE_HEADER_SIZE;


            if (payloadSize < 0)
            {
                Console.WriteLine(
                    "[-] File is smaller than EVTX header.");

                return;
            }


            int remainder =
                payloadSize %
                CHUNK_SIZE;


            Console.WriteLine(
                "[+] File-header size: " +
                FILE_HEADER_SIZE +
                " bytes");

            Console.WriteLine(
                "[+] Chunk size: " +
                CHUNK_SIZE +
                " bytes");

            Console.WriteLine(
                "[+] Data after header: " +
                payloadSize +
                " bytes");

            Console.WriteLine(
                "[+] Chunk remainder: " +
                remainder +
                " bytes");


            if (remainder != 0)
            {
                Console.WriteLine(
                    "[!] File is not an exact multiple of " +
                    CHUNK_SIZE +
                    " after the header.");
            }


            int offset =
                FILE_HEADER_SIZE;

            int chunkIndex = 0;


            while (offset + CHUNK_SIZE <=
                   Data.Length)
            {
                Console.WriteLine();
                Console.WriteLine(
                    "----------------------------------------");

                Console.WriteLine(
                    "Chunk #" +
                    chunkIndex);

                Console.WriteLine(
                    "Offset: " +
                    offset);


                EvtxChunk chunk =
                    new EvtxChunk(
                        Data,
                        offset,
                        chunkIndex);


                if (!chunk.Parse())
                {
                    Console.WriteLine(
                        "[-] Invalid chunk.");

                    break;
                }


                Chunks.Add(chunk);


                offset +=
                    CHUNK_SIZE;

                chunkIndex++;
            }
        }


        public bool ValidateAllSizes()
        {
            bool allOk = true;

            const int FILE_HEADER_SIZE = 4096;
            const int CHUNK_SIZE = 65536;


            Console.WriteLine();
            Console.WriteLine(
                "[File] Expected header size: " +
                FILE_HEADER_SIZE);

            if (Data.Length < FILE_HEADER_SIZE)
            {
                Console.WriteLine(
                    "[File] FAILED: file smaller than header.");

                allOk = false;
            }


            int payloadSize =
                Data.Length -
                FILE_HEADER_SIZE;


            if (payloadSize >= 0)
            {
                int remainder =
                    payloadSize %
                    CHUNK_SIZE;

                Console.WriteLine(
                    "[File] Payload after header: " +
                    payloadSize);

                Console.WriteLine(
                    "[File] Chunk remainder: " +
                    remainder);

                if (remainder != 0)
                {
                    Console.WriteLine(
                        "[File] FAILED: incomplete chunk remainder.");

                    allOk = false;
                }
                else
                {
                    Console.WriteLine(
                        "[File] Chunk alignment: OK");
                }
            }


            foreach (EvtxChunk chunk in Chunks)
            {
                if (!chunk.ValidateSizes())
                    allOk = false;
            }


            return allOk;
        }


        private bool CheckFileHeader()
        {
            byte[] magic =
                Encoding.ASCII.GetBytes(
                    "ElfFile");


            if (Data.Length <
                magic.Length)
            {
                return false;
            }


            for (int i = 0;
                 i < magic.Length;
                 i++)
            {
                if (Data[i] != magic[i])
                    return false;
            }


            return true;
        }
    }


    // ============================================================
    // EVTX CHUNK
    // ============================================================

    class EvtxChunk
    {
        private byte[] Data;

        private int Offset;

        private int Index;


        public List<EvtxRecord> Records =
            new List<EvtxRecord>();


        public EvtxChunk(
            byte[] data,
            int offset,
            int index)
        {
            Data = data;

            Offset = offset;

            Index = index;
        }


        public bool Parse()
        {
            const int CHUNK_SIZE = 65536;


            if (Offset + CHUNK_SIZE >
                Data.Length)
            {
                Console.WriteLine(
                    "[-] Chunk exceeds file.");

                return false;
            }


            if (Offset + 7 >
                Data.Length)
            {
                return false;
            }


            string signature =
                Encoding.ASCII.GetString(
                    Data,
                    Offset,
                    7);


            if (signature !=
                "ElfChnk")
            {
                Console.WriteLine(
                    "[-] Invalid chunk signature: " +
                    signature);

                return false;
            }


            Console.WriteLine(
                "[+] Signature : ElfChnk");


            ulong firstRecordId =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 8);


            ulong lastRecordId =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 16);


            uint firstRecordOffset =
                BitConverter.ToUInt32(
                    Data,
                    Offset + 24);


            uint lastRecordOffset =
                BitConverter.ToUInt32(
                    Data,
                    Offset + 28);


            Console.WriteLine(
                "[+] First Record ID: " +
                firstRecordId);


            Console.WriteLine(
                "[+] Last Record ID: " +
                lastRecordId);


            Console.WriteLine(
                "[+] First Record Offset: " +
                firstRecordOffset);


            Console.WriteLine(
                "[+] Last Record Offset: " +
                lastRecordOffset);


            int searchStart =
                Offset + 512;


            int searchEnd =
                Offset + CHUNK_SIZE;


            int recordIndex = 0;


            for (int pos = searchStart;
                 pos + 8 <= searchEnd;
                 pos++)
            {
                if (!IsRecordSignature(pos))
                    continue;


                EvtxRecord record =
                    new EvtxRecord(
                        Data,
                        pos,
                        Index,
                        recordIndex);


                if (record.Parse())
                {
                    Records.Add(record);

                    recordIndex++;


                    if (record.RecordSize >= 24)
                    {
                        pos +=
                            (int)record.RecordSize -
                            1;
                    }
                }
            }


            Console.WriteLine(
                "[+] Records found: " +
                Records.Count);


            return true;
        }


        public bool ValidateSizes()
        {
            bool ok = true;

            const int CHUNK_SIZE = 65536;


            Console.WriteLine();
            Console.WriteLine(
                "[Chunk " +
                Index +
                "]");


            /*
             * Actual chunk boundary.
             */

            int chunkEnd =
                Offset +
                CHUNK_SIZE;


            Console.WriteLine(
                "  Offset: " +
                Offset);

            Console.WriteLine(
                "  Expected size: " +
                CHUNK_SIZE);

            Console.WriteLine(
                "  End offset: " +
                chunkEnd);


            if (chunkEnd <= Data.Length)
            {
                Console.WriteLine(
                    "  Chunk boundary: OK");
            }
            else
            {
                Console.WriteLine(
                    "  Chunk boundary: FAILED");

                ok = false;
            }


            /*
             * Validate every record.
             */

            foreach (EvtxRecord record in Records)
            {
                if (!record.ValidateSize())
                    ok = false;
            }


            /*
             * Sum record sizes.
             */

            long totalRecordBytes = 0;

            foreach (EvtxRecord record in Records)
            {
                totalRecordBytes +=
                    record.RecordSize;
            }


            Console.WriteLine(
                "  Sum of RecordSize values: " +
                totalRecordBytes +
                " bytes");


            return ok;
        }


        private bool IsRecordSignature(
            int position)
        {
            if (position + 4 >
                Data.Length)
            {
                return false;
            }


            return
                Data[position] == 0x2A &&
                Data[position + 1] == 0x2A &&
                Data[position + 2] == 0x00 &&
                Data[position + 3] == 0x00;
        }
    }


    // ============================================================
    // EVTX RECORD
    // ============================================================

    class EvtxRecord
    {
        private byte[] Data;


        public int Offset;

        public int ChunkIndex;

        public int Index;

        public uint RecordSize;

        public ulong RecordId;

        public ulong Timestamp;

        public int BinXmlSize;

        public byte[] BinXml;


        public EvtxRecord(
            byte[] data,
            int offset,
            int chunkIndex,
            int index)
        {
            Data = data;

            Offset = offset;

            ChunkIndex = chunkIndex;

            Index = index;
        }


        public bool Parse()
        {
            if (Offset + 24 >
                Data.Length)
            {
                return false;
            }


            if (!IsSignature())
                return false;


            RecordSize =
                BitConverter.ToUInt32(
                    Data,
                    Offset + 4);


            RecordId =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 8);


            Timestamp =
                BitConverter.ToUInt64(
                    Data,
                    Offset + 16);


            if (RecordSize < 24)
                return false;


            if (RecordSize > 65536)
                return false;


            if (Offset + RecordSize >
                Data.Length)
            {
                return false;
            }


            /*
             * Record footer.
             */

            uint footerRecordSize =
                BitConverter.ToUInt32(
                    Data,
                    Offset +
                    (int)RecordSize -
                    4);


            if (footerRecordSize !=
                RecordSize)
            {
                Console.WriteLine(
                    "[!] Record footer mismatch.");

                Console.WriteLine(
                    "    Header: " +
                    RecordSize);

                Console.WriteLine(
                    "    Footer: " +
                    footerRecordSize);
            }


            /*
             * Record structure:
             *
             * 24-byte fixed header
             * BinXML
             * 4-byte trailing RecordSize
             */

            BinXmlSize =
                (int)RecordSize -
                24 -
                4;


            if (BinXmlSize <= 0)
                return false;


            BinXml =
                new byte[BinXmlSize];


            Buffer.BlockCopy(
                Data,
                Offset + 24,
                BinXml,
                0,
                BinXmlSize);


            PrintRecord();


            /*
             * Patch target.
             */

            /*
             * TEST:
             *
             * Chỉ zero đúng parameter/value được tìm thấy,
             * không zero toàn bộ BinXML.
             *
             * Ví dụ parameter hiện tại:
             *
             * "This is a test entry written to the event log."
             *
             * Code chỉ thay các byte UTF-16LE của parameter
             * đó bằng 0x00.
             *
             * RecordSize và BinXmlSize không thay đổi.
             */

            string targetText =
                "This is a test entry written to the event log.";

            bool zeroed =
                ZeroUtf16Parameter(
                    BinXml,
                    targetText);

            if (zeroed)
            {
                /*
                 * Ghi BinXML đã chỉnh sửa trở lại
                 * đúng vùng BinXML của record.
                 */

                Buffer.BlockCopy(
                    BinXml,
                    0,
                    Data,
                    Offset + 24,
                    BinXmlSize);

                Console.WriteLine(
                    "[+] Only target parameter was zeroed.");

                Console.WriteLine(
                    "[+] RecordSize unchanged: " +
                    RecordSize);

                Console.WriteLine(
                    "[+] BinXML size unchanged: " +
                    BinXmlSize);
            }


            return true;
        }


        public bool ValidateSize()
        {
            bool ok = true;


            Console.WriteLine();
            Console.WriteLine(
                "  [Record #" +
                Index +
                "]");


            Console.WriteLine(
                "    Offset: " +
                Offset);


            Console.WriteLine(
                "    RecordSize: " +
                RecordSize);


            /*
             * Validate record stays inside file.
             */

            long recordEnd =
                (long)Offset +
                RecordSize;


            Console.WriteLine(
                "    Record end: " +
                recordEnd);


            if (recordEnd <=
                Data.Length)
            {
                Console.WriteLine(
                    "    Boundary: OK");
            }
            else
            {
                Console.WriteLine(
                    "    Boundary: FAILED");

                ok = false;
            }


            /*
             * Validate BinXML calculation.
             */

            int expectedBinXmlSize =
                (int)RecordSize -
                24 -
                4;


            Console.WriteLine(
                "    Expected BinXML size: " +
                expectedBinXmlSize);


            Console.WriteLine(
                "    Actual BinXML size: " +
                BinXmlSize);


            if (expectedBinXmlSize ==
                BinXmlSize)
            {
                Console.WriteLine(
                    "    BinXML size: OK");
            }
            else
            {
                Console.WriteLine(
                    "    BinXML size: FAILED");

                ok = false;
            }


            /*
             * Validate trailing RecordSize.
             */

            uint footerRecordSize =
                BitConverter.ToUInt32(
                    Data,
                    Offset +
                    (int)RecordSize -
                    4);


            Console.WriteLine(
                "    Header RecordSize: " +
                RecordSize);


            Console.WriteLine(
                "    Footer RecordSize: " +
                footerRecordSize);


            if (footerRecordSize ==
                RecordSize)
            {
                Console.WriteLine(
                    "    Header/Footer size: OK");
            }
            else
            {
                Console.WriteLine(
                    "    Header/Footer size: FAILED");

                ok = false;
            }


            return ok;
        }


        private bool ZeroUtf16Parameter(
            byte[] data,
            string targetText)
        {
            byte[] targetBytes =
                Encoding.Unicode.GetBytes(
                    targetText);

            int position =
                FindBytes(
                    data,
                    targetBytes);

            if (position < 0)
            {
                Console.WriteLine(
                    "[-] Target parameter not found.");

                return false;
            }

            Console.WriteLine();
            Console.WriteLine(
                "[+] TARGET PARAMETER FOUND");

            Console.WriteLine(
                "    Text: " +
                targetText);

            Console.WriteLine(
                "    BinXML offset: " +
                position);

            Console.WriteLine(
                "    Absolute file offset: " +
                (Offset + 24 + position));

            Console.WriteLine(
                "    Parameter size: " +
                targetBytes.Length +
                " bytes");

            /*
             * Zero ONLY the bytes belonging to this
             * target parameter.
             *
             * No insertion.
             * No deletion.
             * No RecordSize modification.
             * No BinXML size modification.
             */

            Array.Clear(
                data,
                position,
                targetBytes.Length);

            Console.WriteLine(
                "[+] Parameter bytes overwritten with 0x00.");

            return true;
        }


        private bool PatchUtf16String(
            byte[] data,
            string oldText,
            string newText)
        {
            byte[] oldBytes =
                Encoding.Unicode.GetBytes(
                    oldText);


            byte[] newBytes =
                Encoding.Unicode.GetBytes(
                    newText);


            int position =
                FindBytes(
                    data,
                    oldBytes);


            if (position < 0)
            {
                return false;
            }


            Console.WriteLine();
            Console.WriteLine(
                "[+] Target string found.");

            Console.WriteLine(
                "    BinXML offset: " +
                position);

            Console.WriteLine(
                "    Absolute file offset: " +
                (Offset + 24 + position));

            Console.WriteLine(
                "    Old size: " +
                oldBytes.Length);

            Console.WriteLine(
                "    New size: " +
                newBytes.Length);


            /*
             * Keep the same byte count.
             */

            if (newBytes.Length >
                oldBytes.Length)
            {
                Console.WriteLine(
                    "[-] New text is larger than old text.");

                return false;
            }


            Buffer.BlockCopy(
                newBytes,
                0,
                data,
                position,
                newBytes.Length);


            int remaining =
                oldBytes.Length -
                newBytes.Length;


            /*
             * Fill remaining UTF-16 code units
             * with spaces.
             */

            if (remaining > 0)
            {
                byte[] padding =
                    new byte[remaining];


                for (int i = 0;
                     i + 1 < padding.Length;
                     i += 2)
                {
                    padding[i] = 0x20;
                    padding[i + 1] = 0x00;
                }


                Buffer.BlockCopy(
                    padding,
                    0,
                    data,
                    position +
                    newBytes.Length,
                    remaining);
            }


            Console.WriteLine(
                "[+] String region size preserved: " +
                oldBytes.Length +
                " bytes");


            return true;
        }


        private int FindBytes(
            byte[] data,
            byte[] pattern)
        {
            if (pattern == null ||
                pattern.Length == 0)
            {
                return -1;
            }


            if (data.Length <
                pattern.Length)
            {
                return -1;
            }


            for (int i = 0;
                 i <= data.Length -
                 pattern.Length;
                 i++)
            {
                bool match = true;


                for (int j = 0;
                     j < pattern.Length;
                     j++)
                {
                    if (data[i + j] !=
                        pattern[j])
                    {
                        match = false;
                        break;
                    }
                }


                if (match)
                    return i;
            }


            return -1;
        }


        private void PrintRecord()
        {
            Console.WriteLine();
            Console.WriteLine(
                "Record #" +
                Index);

            Console.WriteLine(
                "Offset: " +
                Offset);

            Console.WriteLine(
                "RecordSize: " +
                RecordSize);

            Console.WriteLine(
                "Record ID: " +
                RecordId);

            Console.WriteLine(
                "BinXML size: " +
                BinXmlSize);


            try
            {
                DateTime time =
                    DateTime.FromFileTimeUtc(
                        (long)Timestamp);

                Console.WriteLine(
                    "Timestamp: " +
                    time.ToString(
                        "yyyy-MM-dd HH:mm:ss.fffffff"));
            }
            catch
            {
                Console.WriteLine(
                    "Timestamp: invalid");
            }
        }


        private bool IsSignature()
        {
            if (Offset + 4 >
                Data.Length)
            {
                return false;
            }


            return
                Data[Offset] == 0x2A &&
                Data[Offset + 1] == 0x2A &&
                Data[Offset + 2] == 0x00 &&
                Data[Offset + 3] == 0x00;
        }
    }
}
