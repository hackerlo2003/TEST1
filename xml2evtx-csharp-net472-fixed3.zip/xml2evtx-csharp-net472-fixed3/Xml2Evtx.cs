// Port of JPCERTCC/xml2evtx.py to C# / .NET Framework 4.7.2
// No third-party dependencies.
// Usage: Xml2Evtx.exe -x input.xml [-v]
//        Xml2Evtx.exe -t [-v]

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

internal static class Xml2Evtx
{
    const ulong EVTX_HEADER_SIGNATURE = 0x456c6646696c6500UL;
    const ulong EVTX_CHUNK_HEADER_SIGNATURE = 0x456C6643686E6B00UL;
    const uint EVTX_EVENT_RECORD_HEADER_SIGNATURE = 0x2a2a0000U;
    const uint FLAGMENT_HEADER = 0x0f010100U;
    const ushort EVTX_MAJOR_VERSION = 0x0003;
    const ushort EVTX_MINOR_VERSION = 0x0002;
    const int MAX_CHUNK_SIZE = 0x10000;
    const int HEADER_SIZE = 128;
    const int HEADER_BLOCK_SIZE = 4096;
    const ulong START_EVENT_RECORD_ID = 1;

    const byte EOF = 0x00;
    const byte OPEN_NO_ATTR = 0x01;
    const byte CLOSE_START = 0x02;
    const byte CLOSE_EMPTY = 0x03;
    const byte END_ELEMENT = 0x04;
    const byte VALUE = 0x05;
    const byte ATTRIBUTE = 0x06;
    const byte OPEN_ATTR = 0x41;
    const byte VALUE_NEXT = 0x45;
    const byte ATTRIBUTE_NEXT = 0x46;
    const byte STRING_TYPE = 0x01;

    static bool Verbose;

    static readonly string TEST_EVENTLOG = @"<?xml version=""1.0"" encoding=""utf-8"" standalone=""yes""?>
<Event xmlns=""http://schemas.microsoft.com/win/2004/08/events/event">
<System>
    <Provider Name=""Microsoft-Windows-Security-Auditing"" Guid=""{54849625-5478-4994-A5BA-3E3B0328C30D}""/>
    <EventID>4624</EventID><Version>2</Version><Level>0</Level><Task>12544</Task><Opcode>0</Opcode>
    <Keywords>0x8020000000000000</Keywords><TimeCreated SystemTime=""2015-11-12T00:24:35.079785200Z""/>
    <EventRecordID>211</EventRecordID><Correlation ActivityID=""{00D66690-1CDF-0000-AC66-D600DF1CD101}""/>
    <Execution ProcessID=""716"" ThreadID=""760""/><Channel>Security</Channel><Computer>WIN-GG82ULGC9GO</Computer><Security/>
</System>
<EventData>
    <Data Name=""SubjectUserSid"">S-1-5-18</Data><Data Name=""SubjectUserName"">WIN-GG82ULGC9GO$</Data>
    <Data Name=""SubjectDomainName"">WORKGROUP</Data><Data Name=""SubjectLogonId"">0x3e7</Data>
    <Data Name=""TargetUserSid"">S-1-5-21-1377283216-344919071-3415362939-500</Data><Data Name=""TargetUserName"">Administrator</Data>
    <Data Name=""TargetDomainName"">WIN-GG82ULGC9GO</Data><Data Name=""TargetLogonId"">0x8dcdc</Data>
    <Data Name=""LogonType"">2</Data><Data Name=""LogonProcessName"">User32</Data><Data Name=""AuthenticationPackageName"">Negotiate</Data>
    <Data Name=""WorkstationName"">WIN-GG82ULGC9GO</Data><Data Name=""LogonGuid"">{00000000-0000-0000-0000-000000000000}</Data>
    <Data Name=""TransmittedServices"">-</Data><Data Name=""LmPackageName"">-</Data><Data Name=""KeyLength"">0</Data>
    <Data Name=""ProcessId"">0x44c</Data><Data Name=""ProcessName"">C:\\Windows\\System32\\svchost.exe</Data>
    <Data Name=""IpAddress"">127.0.0.1</Data><Data Name=""IpPort"">0</Data><Data Name=""ImpersonationLevel"">Impersonation</Data>
    <Data Name=""RestrictedAdminMode"">-</Data><Data Name=""TargetOutboundUserName"">-</Data><Data Name=""TargetOutboundDomainName"">-</Data>
    <Data Name=""VirtualAccount"">No</Data><Data Name=""TargetLinkedLogonId"">0x0</Data><Data Name=""ElevatedToken"">No</Data>
</EventData></Event>";

    static void Log(string msg, bool debug = false)
    {
        if (debug && !Verbose) return;
        Console.Error.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " - " + (debug ? "DEBUG" : "INFO") + " - " + msg);
    }

    static byte[] U16(ushort v) { return BitConverter.GetBytes(v); }
    static byte[] U32(uint v) { return BitConverter.GetBytes(v); }
    static byte[] U64(ulong v) { return BitConverter.GetBytes(v); }
    static byte[] BE32(uint v)
    {
        return new[] { (byte)(v >> 24), (byte)(v >> 16), (byte)(v >> 8), (byte)v };
    }
    static void Add(List<byte> b, byte[] x) { b.AddRange(x); }

    static byte[] Utf16Le(string s) { return Encoding.Unicode.GetBytes(s); }

    static byte[] ToWordPack(string s)
    {
        var b = new List<byte>(s.Length * 2);
        foreach (char c in s) { b.Add((byte)c); b.Add(0); }
        return b.ToArray();
    }

    static ushort CalcNameHash(string s)
    {
        uint h = 0;
        foreach (char c in s) h = (h * 65599U + c) & 0xffffffffU;
        return (ushort)(h & 0xffff);
    }

    static byte[] NameChunk(string name)
    {
        Log("     element name: " + name, true);
        var b = new List<byte>();
        Add(b, U32(0));
        Add(b, U16(CalcNameHash(name)));
        Add(b, U16((ushort)name.Length));
        Add(b, ToWordPack(name));
        Add(b, U16(0));
        return b.ToArray();
    }

    static byte[] ValueChunk(string value)
    {
        Log("        value: " + value, true);
        var b = new List<byte>();
        b.Add(VALUE); b.Add(STRING_TYPE); Add(b, U16((ushort)value.Length));
        Add(b, ToWordPack(value));
        return b.ToArray();
    }

    static byte[] AttributeChunk(XmlElement element)
    {
        Log("  create attribute.", true);
        var body = new List<byte>();
        for (int i = 0; i < element.Attributes.Count; i++)
        {
            XmlAttribute a = element.Attributes[i];
            body.Add(i == element.Attributes.Count - 1 ? ATTRIBUTE : ATTRIBUTE_NEXT);
            Add(body, U32(0x88888888));
            Add(body, NameChunk(a.Name));
            Add(body, ValueChunk(a.Value));
        }
        var b = new List<byte>();
        Add(b, U32((uint)body.Count));
        Add(b, body.ToArray());
        return b.ToArray();
    }

    static byte[] ElementStart(byte[] data, byte token)
    {
        Log("create start element", true);
        var b = new List<byte>();
        b.Add(token);
        Add(b, U32((uint)(data.Length + 4)));
        Add(b, U32(0x99999999));
        Add(b, data);
        return b.ToArray();
    }

    static byte[] CreateEventDetails(XmlElement first)
    {
        var result = new List<byte>();
        foreach (XmlNode n in first.ChildNodes)
        {
            XmlElement child = n as XmlElement;
            if (child == null) continue;
            var data = new List<byte>();
            Add(data, NameChunk(child.Name));
            bool hasText = child.InnerText.Length > 0 && child.ChildNodes.Count > 0 &&
                           child.ChildNodes.Cast<XmlNode>().Any(x => x.NodeType == XmlNodeType.Text);
            byte close = hasText ? END_ELEMENT : CLOSE_EMPTY;
            if (child.Attributes.Count > 0)
            {
                Add(data, AttributeChunk(child));
                if (hasText)
                {
                    data.Add(CLOSE_START);
                    Add(data, ValueChunk(child.InnerText));
                }
                data.Add(close);
                Add(result, ElementStart(data.ToArray(), OPEN_ATTR));
            }
            else
            {
                if (hasText)
                {
                    data.Add(CLOSE_START);
                    Add(data, ValueChunk(child.InnerText));
                }
                data.Add(close);
                Add(result, ElementStart(data.ToArray(), OPEN_NO_ATTR));
            }
        }
        return result.ToArray();
    }

    static byte[] ProcessNodes(XmlElement node)
    {
        var result = new List<byte>();
        foreach (XmlNode n in node.ChildNodes)
        {
            XmlElement first = n as XmlElement;
            if (first == null) continue;
            byte[] details = CreateEventDetails(first);
            var data = new List<byte>();
            Add(data, NameChunk(first.Name));
            data.Add(CLOSE_START);
            Add(data, details);
            Add(result, ElementStart(data.ToArray(), OPEN_NO_ATTR));
            result.Add(END_ELEMENT);
        }
        return result.ToArray();
    }

    static byte[] CreateEventRecord(byte[] data, int count)
    {
        Log("create event records.", true);
        var b = new List<byte>();
        Add(b, BE32(EVTX_EVENT_RECORD_HEADER_SIGNATURE));
        Add(b, U32((uint)(data.Length + 0x20)));
        Add(b, U64(START_EVENT_RECORD_ID + (ulong)count - 1));
        Add(b, U64(GetNtTime(DateTime.UtcNow)));
        Add(b, BE32(FLAGMENT_HEADER));
        Add(b, data);
        Add(b, U32((uint)(data.Length + 0x20)));
        return b.ToArray();
    }

    static byte[] ConvertXmlToBinXml(XmlElement node, int eventNumber)
    {
        Log("convert xml to bin.", true);
        var b = new List<byte>();
        Add(b, NameChunk("Event"));
        var attrs = new List<byte>();
        attrs.Add(ATTRIBUTE);
        Add(attrs, U32(0x88888888));
        Add(attrs, NameChunk("xmlns"));
        Add(attrs, ValueChunk("http://schemas.microsoft.com/win/2004/08/events/event"));
        var attrBlock = new List<byte>();
        Add(attrBlock, U32((uint)attrs.Count));
        Add(attrBlock, attrs.ToArray());
        Add(b, attrBlock.ToArray());
        b.Add(CLOSE_START);
        Add(b, ProcessNodes(node));
        byte[] element = ElementStart(b.ToArray(), OPEN_ATTR);
        var all = new List<byte>();
        Add(all, element);
        all.Add(END_ELEMENT);
        all.Add(EOF);
        return CreateEventRecord(all.ToArray(), eventNumber);
    }

    static ulong GetNtTime(DateTime utc)
    {
        return (ulong)((utc.Ticks - new DateTime(1601, 1, 1, 0, 0, 0, DateTimeKind.Utc).Ticks) / 10);
    }

    static byte[] CreateEvtxChunk(byte[] data, int eventCount)
    {
        Log("set evtx chunk header.", true);

        // EVTX chunk header is exactly 0x80 bytes.
        // Layout must match EVTX_CHUNK_HEADER from the original Python implementation:
        //   0x00  signature                         Q (BE)
        //   0x08  first event record number         Q
        //   0x10  last event record number          Q
        //   0x18  first event record identifier     Q
        //   0x20  last event record identifier      Q
        //   0x28  header size                       I
        //   0x2c  last event record offset          I
        //   0x30  free space offset                 I
        //   0x34  event records checksum            I
        //   0x38  unknown                            64 bytes
        //   0x78  unknown                            I
        //   0x7c  chunk checksum                    I
        ulong lastEventRecordNumber = START_EVENT_RECORD_ID + (ulong)eventCount - 1;
        uint freeSpaceOffset = (uint)(data.Length + 0x0200);

        var h = new List<byte>(HEADER_SIZE);
        Add(h, BE64(EVTX_CHUNK_HEADER_SIGNATURE));
        Add(h, U64(0x01));
        Add(h, U64((ulong)eventCount));
        Add(h, U64(START_EVENT_RECORD_ID));
        Add(h, U64(lastEventRecordNumber));
        Add(h, U32(HEADER_SIZE));
        Add(h, U32(0));                         // last_event_record_offset, patched later
        Add(h, U32(freeSpaceOffset));           // IMPORTANT: this field was missing
        Add(h, U32(Crc32(data)));                // event_records_checksum
        Add(h, new byte[64]);
        Add(h, U32(0x01));
        Add(h, U32(0));                         // chunk checksum, patched later

        if (h.Count != HEADER_SIZE)
            throw new InvalidOperationException("Internal EVTX chunk header size error: " + h.Count);

        // Common string offset array: 384 bytes, from 0x80 through 0x1ff.
        byte[] commonStringOffset = new byte[384];

        // Same checksum calculation as the Python implementation:
        // CRC32(header[0:120] + common_string_offset).
        uint headerCrc = Crc32(Concat(h.Take(120).ToArray(), commonStringOffset));
        WriteU32(h, 124, headerCrc);

        return Concat(h.ToArray(), commonStringOffset, data);
    }

    static byte[] CreateChunk(byte[] binxml, int totalEventCount, int totalChunkCount)
    {
        byte[] fixedBinxml = FixBinXmlOffset(binxml);
        byte[] part = CreateEvtxChunk(fixedBinxml, totalEventCount);
        int blank = MAX_CHUNK_SIZE - part.Length;
        if (blank < 0) throw new InvalidOperationException("EVTX chunk exceeded 0x10000 bytes.");
        part = Concat(part, new byte[blank]);

        // Match xml2evtx.py::create_chunk exactly:
        // 1) patch last_event_record_offset at 0x2c with the offset of
        //    the last 0x2a2a0000 event-record signature.
        // 2) recalculate event_records_checksum at 0x7c over
        //    chunk[0:120] + chunk[128:512].
        uint lastRecordOffset = FindLastSignature(part, new byte[] { 0x2a, 0x2a, 0x00, 0x00 });
        WriteU32(part, 0x2c, lastRecordOffset);

        uint eventRecordsChecksum = Crc32(
            Concat(
                part.Take(120).ToArray(),
                part.Skip(128).Take(384).ToArray()
            )
        );
        WriteU32(part, 0x7c, eventRecordsChecksum);

        Log("blank size is " + blank, true);
        Log("finised chank " + totalChunkCount + ".");
        return part;
    }

    static byte[] FixBinXmlOffset(byte[] binxml)
    {
        var b = (byte[])binxml.Clone();
        ReplaceMarker(b, 0x99999999U);
        ReplaceMarker(b, 0x88888888U);
        return b;
    }

    static void ReplaceMarker(byte[] b, uint marker)
    {
        byte[] p = U32(marker);
        for (int i = 0; i <= b.Length - 4; i++)
        {
            if (b[i] == p[0] && b[i+1] == p[1] && b[i+2] == p[2] && b[i+3] == p[3])
                WriteU32(b, i, (uint)(i + 0x204));
        }
    }

    static byte[] CreateEvtx(byte[] data, int eventCount, int chunkCount)
    {
        Log("set evtx header.", true);
        var h = new List<byte>();
        Add(h, BE64(EVTX_HEADER_SIGNATURE));
        Add(h, U64(0));
        Add(h, U64((ulong)chunkCount));
        Add(h, U64(START_EVENT_RECORD_ID + (ulong)eventCount));
        Add(h, U32(HEADER_SIZE));
        Add(h, U16(EVTX_MINOR_VERSION));
        Add(h, U16(EVTX_MAJOR_VERSION));
        Add(h, U16(HEADER_BLOCK_SIZE));
        Add(h, U16((ushort)(chunkCount + 1)));
        Add(h, new byte[76]);
        Add(h, U32(0x0001));
        Add(h, U32(0));
        Add(h, new byte[3968]);
        uint crc = Crc32(h.Take(120).ToArray());
        WriteU32(h, 124, crc);
        return Concat(h.ToArray(), data);
    }

    static byte[] ProcessXml(string xmlFile, out int eventCount, out int chunkCount)
    {
        eventCount = 0; chunkCount = 0;
        var binxml = new List<byte>();
        var chunks = new List<byte>();
        foreach (XmlElement node in XmlRecords(xmlFile))
        {
            eventCount++;
            Log("load event log " + eventCount, true);
            byte[] part = ConvertXmlToBinXml(node, eventCount);
            if (binxml.Count + part.Length > MAX_CHUNK_SIZE - 0x200)
            {
                chunks.AddRange(CreateChunk(binxml.ToArray(), eventCount, chunkCount));
                binxml.Clear();
                chunkCount++;
            }
            binxml.AddRange(part);
        }
        chunks.AddRange(CreateChunk(binxml.ToArray(), eventCount, chunkCount));
        return chunks.ToArray();
    }

    static IEnumerable<XmlElement> XmlRecords(string filename)
    {
        Log("load xml data.", true);
        Log("read " + filename);
        string xdata = File.ReadAllText(filename, Encoding.UTF8);
        xdata = xdata.Replace("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>", "")
                     .Replace("</Events>", "").Replace("<Events>", "");
        string[] parts = Regex.Split(xdata, "<Event xmlns=['\"]http://schemas.microsoft.com/win/2004/08/events/event['\"]>");
        foreach (string xml in parts)
        {
            if (!xml.TrimStart().StartsWith("<System>", StringComparison.Ordinal)) continue;
            string wrapped = "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?><Event>" + xml;
            XmlDocument doc = new XmlDocument { XmlResolver = null };
            try { doc.LoadXml(wrapped); yield return doc.DocumentElement; }
            catch (XmlException ex) { Log(ex.Message); }
        }
    }

    static IEnumerable<XmlElement> LoadTestData(string data)
    {
        string xdata = data.Replace("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>", "")
                           .Replace("</Events>", "").Replace("<Events>", "");
        string[] parts = Regex.Split(xdata, "<Event xmlns=['\"]http://schemas.microsoft.com/win/2004/08/events/event['\"]>");
        foreach (string xml in parts)
        {
            if (!xml.TrimStart().StartsWith("<System>", StringComparison.Ordinal)) continue;
            XmlDocument doc = new XmlDocument { XmlResolver = null };
            try { doc.LoadXml("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?><Event>" + xml); yield return doc.DocumentElement; }
            catch (XmlException ex) { Log(ex.Message); }
        }
    }

    static byte[] ProcessTest(out int eventCount, out int chunkCount)
    {
        eventCount = 0; chunkCount = 0;
        var binxml = new List<byte>();
        foreach (XmlElement node in LoadTestData(TEST_EVENTLOG))
        {
            eventCount++;
            Log("load event log " + eventCount, true);
            binxml.AddRange(ConvertXmlToBinXml(node, eventCount));
        }
        return CreateChunk(binxml.ToArray(), eventCount, 0);
    }

    static byte[] BE64(ulong v)
    {
        return new[] { (byte)(v >> 56), (byte)(v >> 48), (byte)(v >> 40), (byte)(v >> 32), (byte)(v >> 24), (byte)(v >> 16), (byte)(v >> 8), (byte)v };
    }

    static byte[] Concat(params byte[][] arrays)
    {
        int n = arrays.Sum(a => a.Length); byte[] r = new byte[n]; int p = 0;
        foreach (var a in arrays) { Buffer.BlockCopy(a, 0, r, p, a.Length); p += a.Length; }
        return r;
    }

    static uint FindLastSignature(byte[] data, byte[] sig)
    {
        // xml2evtx.py uses re.finditer() and keeps the LAST match.
        // The last 2a2a0000 marker is therefore the start of the last event record.
        uint last = 0;
        bool found = false;
        for (int i = 0; i <= data.Length - sig.Length; i++)
        {
            bool ok = true;
            for (int j = 0; j < sig.Length; j++)
            {
                if (data[i + j] != sig[j]) { ok = false; break; }
            }
            if (ok)
            {
                last = (uint)i;
                found = true;
            }
        }
        if (!found)
            throw new InvalidOperationException("EVTX event record signature was not found.");
        return last;
    }

    static void WriteU32(byte[] b, int offset, uint value) { Buffer.BlockCopy(U32(value), 0, b, offset, 4); }
    static void WriteU32(List<byte> b, int offset, uint value) { byte[] x = U32(value); for (int i=0;i<4;i++) b[offset+i]=x[i]; }

    // Standard CRC32 used by zlib.crc32(data), polynomial 0xEDB88320, initial/final XOR 0xffffffff.
    static readonly uint[] CrcTable = MakeCrcTable();
    static uint[] MakeCrcTable()
    {
        var t = new uint[256];
        for (uint i = 0; i < 256; i++) { uint c=i; for(int k=0;k<8;k++) c=((c&1)!=0)?0xEDB88320U^(c>>1):(c>>1); t[i]=c; }
        return t;
    }
    static uint Crc32(byte[] data)
    {
        uint c=0xffffffffU;
        foreach(byte x in data) c=CrcTable[(c^x)&0xff]^(c>>8);
        return c^0xffffffffU;
    }

    static void Main(string[] args)
    {
        string xml = null; bool test = false;
        for (int i=0;i<args.Length;i++)
        {
            if (args[i] == "-x" || args[i] == "--xml") { if (++i >= args.Length) throw new ArgumentException("Missing XML path."); xml=args[i]; }
            else if (args[i] == "-t" || args[i] == "--test") test=true;
            else if (args[i] == "-v" || args[i] == "--verbose") Verbose=true;
            else if (args[i] == "-h" || args[i] == "--help") { Console.WriteLine("Usage: Xml2Evtx.exe -x input.xml [-v] | -t [-v]"); return; }
        }

        Log("start create EVTX.");
        int eventCount, chunkCount; byte[] chunks; string output;
        if (xml != null) { chunks=ProcessXml(xml,out eventCount,out chunkCount); output=xml+".evtx"; }
        else if (test) { chunks=ProcessTest(out eventCount,out chunkCount); output="test.evtx"; }
        else { chunks=ProcessTest(out eventCount,out chunkCount); output="default.evtx"; }
        Log("total event log is " + eventCount + ".");
        byte[] evtx=CreateEvtx(chunks,eventCount,chunkCount);
        File.WriteAllBytes(output,evtx);
        Log("created " + output + ".");
    }
}
